<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    if($_SESSION['user_data']['rank']!=4){
        if($_SESSION['user_data']['rank']!=1){
            session_destroy();
            header("Location:../../logout.php");
        }
        
    }

    $today_date = date("Y-m-d");

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);

    $dataCalendar = array();
    $qCalendar = mysqli_query($con, "SELECT * FROM calendar WHERE '".$today_date."' <= date ORDER BY date ASC LIMIT 5");
    while($rowCalendar=mysqli_fetch_assoc($qCalendar)){
        array_push($dataCalendar,$rowCalendar);
    }

    $dataN = array();
    $qN = mysqli_query($con, "SELECT * FROM notices ORDER BY date ASC LIMIT 5");
    while($rowN=mysqli_fetch_assoc($qN)){
        array_push($dataN,$rowN);
     }

    

}
$title=mysqli_real_escape_string($con,$_REQUEST['title']);
$date=mysqli_real_escape_string($con,$_REQUEST['date']);
$content=mysqli_real_escape_string($con,$_REQUEST['content']);


$q = mysqli_query($con, "INSERT into calendar (title, date, content) values ('".$title."','".$date."','".$content."')");
if ($q) {
    header("Location:all-calendar.php?success=Added Successfully");
}
else {
    header("Location:all-calendar.php?error=Failed to add Upcoming Event");
}
?>