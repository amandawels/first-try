<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
// $pich = $_FILES['leadership_pic']['name'] . 'fuck';
$leadership=mysqli_real_escape_string($con,$_REQUEST['leadership']);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into settings (slide_pic_1) values ('".$slide_pic_1."') WHERE id=1");

    $pich = $_FILES['leadership_pic']['name'] . 'fuck';

    $leadership_pic = time() . '_' . $_FILES['leadership_pic']['name'];
    $destination = "../../../../settings/" . $leadership_pic;
    $result = move_uploaded_file($_FILES['leadership_pic']['tmp_name'], $destination);

    if($pich == "fuck"){
        // echo "fuck haipo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET leadership='".$_REQUEST['leadership']."' WHERE id=1");
    } else {
        
        // echo "fuck iripo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET leadership_pic='".$leadership_pic."', leadership='".$_REQUEST['leadership']."' WHERE id=1");
        
    }
    // $q1 = mysqli_query($con, "UPDATE settings SET leadership_pic='".$leadership_pic."', leadership_pic_head='".$_REQUEST['leadership_pic_head']."',leadership_pic_text='".$_REQUEST['leadership_pic_text']."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated School leadership Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to Update School leadership");
    }  
}

?>