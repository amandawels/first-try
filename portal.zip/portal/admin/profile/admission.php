<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$admission=mysqli_real_escape_string($con,$_REQUEST['admission']);

// $pic = time() . '_' . $_FILES['pic']['name'];
// $destination = "../../../images/gallery/" . $pic;
// $result = move_uploaded_file($_FILES['pic']['tmp_name'], $destination);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into users (pic) values ('".$pic."') WHERE id='".$_REQUEST['id']."'");
    $q1 = mysqli_query($con, "UPDATE settings SET admission='".$_REQUEST['admission']."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated Admission Article Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to update Admission Article");
    }  
}

?>