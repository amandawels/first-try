<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$facebook=mysqli_real_escape_string($con,$_REQUEST['facebook']);
$instagram=mysqli_real_escape_string($con,$_REQUEST['instagram']);
$whatsapp=mysqli_real_escape_string($con,$_REQUEST['whatsapp']);
$linkedin=mysqli_real_escape_string($con,$_REQUEST['linkedin']);

// $pic = time() . '_' . $_FILES['pic']['name'];
// $destination = "../../../images/gallery/" . $pic;
// $result = move_uploaded_file($_FILES['pic']['tmp_name'], $destination);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into users (pic) values ('".$pic."') WHERE id='".$_REQUEST['id']."'");
    $q1 = mysqli_query($con, "UPDATE settings SET facebook='".$_REQUEST['facebook']."',instagram='".$_REQUEST['instagram']."',whatsapp='".$_REQUEST['whatsapp']."',linkedin='".$_REQUEST['linkedin']."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated Social Media Details Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to update School Social Media");
    }  
}

?>