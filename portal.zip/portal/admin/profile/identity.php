<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
// $pich = $_FILES['identity_pic']['name'] . 'fuck';
$identity=mysqli_real_escape_string($con,$_REQUEST['identity']);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into settings (slide_pic_1) values ('".$slide_pic_1."') WHERE id=1");

    $pich = $_FILES['identity_pic']['name'] . 'fuck';

    $identity_pic = time() . '_' . $_FILES['identity_pic']['name'];
    $destination = "../../../../settings/" . $identity_pic;
    $result = move_uploaded_file($_FILES['identity_pic']['tmp_name'], $destination);

    if($pich == "fuck"){
        // echo "fuck haipo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET identity='".$_REQUEST['identity']."' WHERE id=1");
    } else {
        
        // echo "fuck iripo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET identity_pic='".$identity_pic."', identity='".$_REQUEST['identity']."' WHERE id=1");
        
    }
    // $q1 = mysqli_query($con, "UPDATE settings SET identity_pic='".$identity_pic."', identity_pic_head='".$_REQUEST['identity_pic_head']."',identity_pic_text='".$_REQUEST['identity_pic_text']."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated School Identity Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to Update School Identity");
    }  
}

?>