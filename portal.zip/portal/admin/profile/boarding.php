<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
// $pich = $_FILES['boarding_life_pic']['name'] . 'fuck';
$boarding_life=mysqli_real_escape_string($con,$_REQUEST['boarding_life']);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into settings (slide_pic_1) values ('".$slide_pic_1."') WHERE id=1");

    $pich = $_FILES['boarding_life_pic']['name'] . 'fuck';

    $boarding_life_pic = time() . '_' . $_FILES['boarding_life_pic']['name'];
    $destination = "../../../../settings/" . $boarding_life_pic;
    $result = move_uploaded_file($_FILES['boarding_life_pic']['tmp_name'], $destination);

    if($pich == "fuck"){
        // echo "fuck haipo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET boarding_life='".$_REQUEST['boarding_life']."' WHERE id=1");
    } else {
        
        // echo "fuck iripo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET boarding_life_pic='".$boarding_life_pic."', boarding_life='".$_REQUEST['boarding_life']."' WHERE id=1");
        
    }
    // $q1 = mysqli_query($con, "UPDATE settings SET boarding_life_pic='".$boarding_life_pic."', boarding_life_pic_head='".$_REQUEST['boarding_life_pic_head']."',boarding_life_pic_text='".$_REQUEST['boarding_life_pic_text']."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated Boarding Life Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to Update Boarding Life");
    }  
}

?>