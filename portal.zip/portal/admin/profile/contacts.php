<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$phone_main=mysqli_real_escape_string($con,$_REQUEST['phone_main']);
$phone_second=mysqli_real_escape_string($con,$_REQUEST['phone_second']);
$email=mysqli_real_escape_string($con,$_REQUEST['email']);

// $pic = time() . '_' . $_FILES['pic']['name'];
// $destination = "../../../images/gallery/" . $pic;
// $result = move_uploaded_file($_FILES['pic']['tmp_name'], $destination);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into users (pic) values ('".$pic."') WHERE id='".$_REQUEST['id']."'");
    $q1 = mysqli_query($con, "UPDATE settings SET phone_main='".$_REQUEST['phone_main']."',phone_second='".$_REQUEST['phone_second']."',email='".$_REQUEST['email']."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated Contact Details Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to update School Contacts");
    }  
}

?>