<?php include "../../path.php";
session_start();
include '../../../../database/connect.php' ;
if(isset($_SESSION['user_data'])){
    if($_SESSION['user_data']['rank']!=4){
        if($_SESSION['user_data']['rank']!=1){
            session_destroy();
            header("Location:../../logout.php");
        }
        
    }

    $today_date = date("Y-m-d");

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);

    $dataCalendar = array();
    $qCalendar = mysqli_query($con, "SELECT * FROM calendar WHERE '".$today_date."' <= date ORDER BY date ASC LIMIT 5");
    while($rowCalendar=mysqli_fetch_assoc($qCalendar)){
        array_push($dataCalendar,$rowCalendar);
    }

    $dataN = array();
    $qN = mysqli_query($con, "SELECT * FROM notices ORDER BY date ASC LIMIT 5");
    while($rowN=mysqli_fetch_assoc($qN)){
        array_push($dataN,$rowN);
     }

    

$id = $_SESSION['user_data']['id'];

$q = mysqli_query($con, "SELECT * FROM users WHERE id='".$id."'");
$row=mysqli_fetch_assoc($q);

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);


?>

<!DOCTYPE html>
<html lang="en">


<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $rowS['short_name'] ?> Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/iconfonts/font-awesome/css/all.min.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../../../settings/<?php echo $rowS['favicon'] ?>" />
</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
            <!-- Open Header -->

<nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row default-layout-navbar">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo" href="../../home.php"><img src="../../../../settings/<?php echo $rowS['logo_main'] ?>" alt="logo"/></a>
        <a class="navbar-brand brand-logo-mini" href="../../home.php"><img src="../../images/logo-mini.png" alt="logo"/></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-stretch">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="fas fa-bars"></span>
        </button>
        
        <ul class="navbar-nav navbar-nav-right">
          
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              <img src="<?php echo ("../../../../images/users/staff/").($_SESSION['user_data']['pic']) ?>" alt="profile"/>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <a class="dropdown-item" href="../profile/profile.php">
                <i class="fas fa-cog text-primary"></i>
                Settings
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="../../logout.php">
                <i class="fas fa-power-off text-primary"></i>
                Logout
              </a>
            </div>
          </li>
          <li class="nav-item nav-settings">
            <a class="nav-link" href="#">
              <i class="fas fa-ellipsis-h"></i>
            </a>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="fas fa-bars"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      
      <div id="right-sidebar" class="settings-panel">
        <i class="settings-close fa fa-times"></i>
        <ul class="nav nav-tabs" id="setting-panel" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="todo-tab" data-toggle="tab" href="#todo-section" role="tab" aria-controls="todo-section" aria-expanded="true">UPCOMING EVENTS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="chats-tab" data-toggle="tab" href="#chats-section" role="tab" aria-controls="chats-section">NOTICES</a>
          </li>
        </ul>

        <div class="tab-content" id="setting-content">
          <div class="tab-pane fade show active scroll-wrapper" id="todo-section" role="tabpanel" aria-labelledby="todo-section">
            <div class="add-items d-flex px-3 mb-0">
              <!-- <form class="form w-100">
                <div class="form-group d-flex">
                  <input type="text" class="form-control todo-list-input" placeholder="Add To-do">
                  <button type="submit" class="add btn btn-primary todo-list-add-btn" id="add-task-todo">Add</button>
                </div>
              </form> -->
            </div>
            <?php foreach ($dataCalendar as $dCalendar): ?>
            <div class="events py-4 border-bottom px-3">
              <div class="wrapper d-flex mb-2">
                <div class="tg-widgetcontent">
                  <div class="item">
                    <div id="tg-comments" class="tg-comments">
                        <div class="tg-comment">
                          <figure><a href="#"></a></figure>
                          <div class="tg-commentcontent">
                            <div class="">
                              <span><i class="fas fa-calendar"></i> <?php $date = $dCalendar['date']; echo date("F d, Y", strtotime($date)); ?></span>
                              <h5><?php echo $dCalendar['title'] ?></h5>
                            </div>
                          </div>
                        </div>		
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
            

          </div>

          <!-- To do section tab ends -->
          <div class="tab-pane fade" id="chats-section" role="tabpanel" aria-labelledby="chats-section">

            <ul class="chat-list">
              <?php foreach ($dataN as $dNotice): ?>
              <li class="list active">
                <div class="profile"><i class="fas fa-calendar"></i></div>
                <div class="info">
                  <p><?php echo $dNotice['title'] ?></p>
                </div>
              </li><br>
              <?php endforeach; ?>
              
            </ul>
          </div>
          <!-- chat tab ends -->
        </div>
      </div>
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">

          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="profile-image">
                <img src="<?php echo ("../../../../images/users/staff/").($_SESSION['user_data']['pic']); ?>" alt="image"/>
              </div>
              <div class="profile-name">
                <p class="name">
                  <?php echo($_SESSION['user_data']['title']." ".$_SESSION['user_data']['surname']); ?>
                </p>
                <p class="designation">
                  <?php $rank=$_SESSION['user_data']['rank']; if ($rank==1){echo "Director";} else if($rank==2){echo "Principal";} else if($rank==3){echo "H.O.D";} else if($rank==4){echo "Administration";} else if($rank==5){echo "Teacher";} else {echo "Non-Teaching Staff";} ?>
                </p>
              </div>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../../home.php">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../students/search.php">
              <i class="fa fa-search menu-icon"></i>
              <span class="menu-title">Search Students</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#publish" aria-expanded="false" aria-controls="publish">
              <i class="fa fa-book menu-icon"></i>
              <span class="menu-title">Publish Results</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="publish">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../../publish.php">End of Term</a></li>
                <li class="nav-item"> <a class="nav-link" href="../../publishT.php">Test Results</a></li>
              </ul>
            </div>
          </li>
          
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#statistics" aria-expanded="false" aria-controls="statistics">
              <i class="fa fa-book menu-icon"></i>
              <span class="menu-title">Statistics</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="statistics">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../statistics/select-stats.php">End of Term</a></li>
                <li class="nav-item"> <a class="nav-link" href="../statisticsTest/select-stats.php">Test Results</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#students" aria-expanded="false" aria-controls="students">
              <i class="fa fa-user menu-icon"></i>
              <span class="menu-title">Students</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="students">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../students/see-students.php">go to class</a></li>
                <li class="nav-item"> <a class="nav-link" href="../students/all-students.php">Manage Students</a></li>
                <li class="nav-item"> <a class="nav-link" href="../students/cArrears.php">Arrears</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#staff" aria-expanded="false" aria-controls="staff">
              <i class="fa fa-user menu-icon"></i>
              <span class="menu-title">Staff</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="staff">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../staff/add-staff.php">Add Staff</a></li>
                <li class="nav-item"> <a class="nav-link" href="../staff/all-staff.php">Manage Staff</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#notice" aria-expanded="false" aria-controls="notice">
              <i class="fa fa-bell menu-icon"></i>
              <span class="menu-title">Notices</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="notice">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../notice/add-notice.php">Add Notice</a></li>
                <li class="nav-item"> <a class="nav-link" href="../notice/all-notice.php">Manage Notices</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#calendar" aria-expanded="false" aria-controls="calendar">
              <i class="fa fa-calendar menu-icon"></i>
              <span class="menu-title">Calendar</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="calendar">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../calendar/add-calendar.php">Add Upcoming Event</a></li>
                <li class="nav-item"> <a class="nav-link" href="../calendar/all-calendar.php">Manage Calendar</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#news" aria-expanded="false" aria-controls="news">
              <i class="fas fa-clipboard-list menu-icon"></i>
              <span class="menu-title">News</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="news">
              <ul class="nav flex-column sub-menu">
              <li class="nav-item"> <a class="nav-link" href="../news/add-news.php">Add News</a></li>
                <li class="nav-item"> <a class="nav-link" href="../news/all-news.php">Manage News</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#gallery" aria-expanded="false" aria-controls="gallery">
              <i class="fa fa-image menu-icon"></i>
              <span class="menu-title">Gallery</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="gallery">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../gallery/add-picture.php">Add Pictures</a></li>
                <li class="nav-item"> <a class="nav-link" href="../gallery/all-pictures.php">Manage Gallery</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#department" aria-expanded="false" aria-controls="department">
              <i class="fas fa-cube menu-icon"></i>
              <span class="menu-title">Departments/Clubs</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="department">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../department/add-department.php">Add Department/Club</a></li>
                <li class="nav-item"> <a class="nav-link" href="../department/all-departments.php">Manage Departments/Clubs</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#downloads" aria-expanded="false" aria-controls="downloads">
              <i class="fa fa-download menu-icon"></i>
              <span class="menu-title">Downloads</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="downloads">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../downloads/add-download.php">Upload File</a></li>
                <li class="nav-item"> <a class="nav-link" href="../downloads/all-downloads.php">Manage Downloads</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#jobs" aria-expanded="false" aria-controls="jobs">
              <i class="fa fa-briefcase menu-icon"></i>
              <span class="menu-title">Vacants</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="jobs">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../jobs/add-job.php">Upload Vacant</a></li>
                <li class="nav-item"> <a class="nav-link" href="../jobs/all-job.php">Manage Vacants</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#subjects" aria-expanded="false" aria-controls="subjects">
              <i class="fa fa-book menu-icon"></i>
              <span class="menu-title">Subjects</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="subjects">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../subjects/add-subject.php">Add Subject</a></li>
                <li class="nav-item"> <a class="nav-link" href="../subjects/select-class.php">Manage Subjects</a></li>
              </ul>
            </div>
          </li>


          <!-- <li class="nav-item">
            <a class="nav-link" href="../statistics/select-stats.php">
              <i class="fa fa-book menu-icon"></i>
              <span class="menu-title">Statistics</span>
            </a>
          </li> -->

          
          <li class="nav-item">
            <a class="nav-link" href="../emails/emails.php">
              <i class="fa fa-envelope menu-icon"></i>
              <span class="menu-title">Emails</span>
            </a>
          </li>

          
          <li class="nav-item">
            <a class="nav-link" href="../sb/sb.php">
              <i class="fa fa-envelope menu-icon"></i>
              <span class="menu-title">Suggestion Box</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../profile/profile.php">
              <i class="fa fa-cog menu-icon"></i>
              <span class="menu-title">Settings</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../../logout.php">
              <i class="fa fa-power-off menu-icon"></i>
              <span class="menu-title">Logout</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../../../../index.php">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Go to Public</span>
            </a>
          </li>

          <br><br><br>

          
        </ul>
      </nav>

      <!-- Close Header -->
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
            <div class="page-header">
                <h3 class="page-title">
                <?php echo $row['name']." ".$row['surname']; ?>
                </h3>
                <a href="edit-profile.php?id=<?php echo $row['id']; ?>" class="btn btn-outline-primary">Edit Personal Details</a>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="../../home.php">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Profile</li>
                    </ol>
                </nav>
            </div>

            <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4 class="card-title">Your Profile</h4></td><br>
                                            <div class="row">
                                                <?php if(isset($_REQUEST['success'])) { ?>
                                                    <div class="col-lg-12">
                                                        <span class="alert alert-success alert-block" style="display: block;"><?php echo $_REQUEST['success']; ?></span>
                                                    </div>
                                                <?php } ?>
                                            </div>  
                                            <div class="row">
                                                <?php if(isset($_REQUEST['error'])) { ?>
                                                    <div class="col-lg-12">
                                                        <span class="alert alert-danger alert-block" style="display: block;"><?php echo $_REQUEST['error']; ?></span>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                                <tr>
                                                                    <th>Name</th>
                                                                    <td><?php echo $row['name']." ".$row['surname']; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Username</th>
                                                                    <td><?php echo $row['username']; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Role</th>
                                                                    <td><?php $rank=$row['rank']; if ($rank==1){echo "Director";} else if($rank==2){echo "Principal";} else if($rank==3){echo "H.O.D";} else if($rank==4){echo "Administration";} else if($rank==5){echo "Teacher";} else {echo "Non-Teaching Staff";} ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Sex</th>
                                                                    <td><?php echo $row['sex']; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Education</th>
                                                                    <td><?php echo $row['level']; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Contact Number</th>
                                                                    <td><?php echo $row['phone']; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Email</th>
                                                                    <td><?php echo $row['email']; ?></td>
                                                                </tr>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>







                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">School Details</h3></td><br>
                                            
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="details.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label for="name">School Name</label>
                                                                    <input name="name" type="text" class="form-control" id="name" placeholder="Name" value="<?php echo $rowS['name'] ?>" required>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="short_name">School Short Name</label>
                                                                    <input name="short_name" type="text" class="form-control" id="short_name" placeholder="Short Name" value="<?php echo $rowS['short_name'] ?>" required>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="motto">School Motto</label>
                                                                    <input name="motto" type="text" class="form-control" id="motto" placeholder="Motto" value="<?php echo $rowS['motto'] ?>" required>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="mission">School Mission</label>
                                                                    <textarea class="form-control" name="mission" id="editor" cols="30" rows="10" placeholder="School Mission"><?php echo $rowS['mission'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'mission' );
                                                                    </script>
                                                                </div>
                                                                <!-- <div class="form-group">
                                                                    <label for="vision">School Vision</label>
                                                                    <textarea class="form-control" name="vision" id="editor" cols="30" rows="10" placeholder="School Vision"><?php echo $rowS['vision'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'vision' );
                                                                    </script>
                                                                </div> -->
                                                                <div class="form-group">
                                                                    <label for="address">School Address</label>
                                                                    <textarea class="form-control" name="address" id="editor" cols="30" rows="10" placeholder="School Address"><?php echo $rowS['address'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'address' );
                                                                    </script>
                                                                </div>

                                                                <button type="submit" name="details_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">Website Slider</h3></td><br>
                                            
                                            <div class="row">
                                                
                                              <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['slide_pic_1'] ?>" alt="Card image">
                                                          <div class="card-img-overlay d-flex">
                                                            <div class="mt-auto text-center w-100">
                                                              <h3><?php echo $rowS['slide_pic_1_head'] ?></h3>
                                                              <h6 class="card-text mb-4 font-weight-normal"><?php echo $rowS['slide_pic_1_text'] ?></h6>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                      
                                                      
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="slide_1.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label>Slider Picture 1 (873p x 424p)</label>
                                                                    <input type="file" name="slide_pic_1" id="slide_pic_1" class="form-control">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="slide_pic_1_head">Slider 1 Header</label>
                                                                    <input name="slide_pic_1_head" type="text" class="form-control" id="slide_pic_1_head" placeholder="Slider Picture 1 Heading" value="<?php echo $rowS['slide_pic_1_head'] ?>" required>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="slide_pic_1_text">Slider 1 Text</label>
                                                                    <textarea class="form-control" name="slide_pic_1_text" id="slide_pic_1_text" cols="30" rows="4" placeholder="Slider Picture 1 Text"><?php echo $rowS['slide_pic_1_text'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'slide_pic_1_text' );
                                                                    </script>
                                                                </div>
                                                             

                                                                <button type="submit" name="slider_1" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>



                                                <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['slide_pic_2'] ?>" alt="Card image">
                                                          <div class="card-img-overlay d-flex">
                                                            <div class="mt-auto text-center w-100">
                                                              <h3><?php echo $rowS['slide_pic_2_head'] ?></h3>
                                                              <h6 class="card-text mb-4 font-weight-normal"><?php echo $rowS['slide_pic_2_text'] ?></h6>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                      
                                                      
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="slide_2.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label>Slider Picture 2 (873p x 424p)</label>
                                                                    <input type="file" name="slide_pic_2" id="slide_pic_2" class="form-control">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="slide_pic_2_head">Slider 2 Header</label>
                                                                    <input name="slide_pic_2_head" type="text" class="form-control" id="slide_pic_2_head" placeholder="Slider Picture 1 Heading" value="<?php echo $rowS['slide_pic_2_head'] ?>" required>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="slide_pic_2_text">Slider 2 Text</label>
                                                                    <textarea class="form-control" name="slide_pic_2_text" id="slide_pic_2_text" cols="30" rows="4" placeholder="Slider Picture 1 Text"><?php echo $rowS['slide_pic_2_text'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'slide_pic_2_text' );
                                                                    </script>
                                                                </div>
                                                             

                                                                <button type="submit" name="slider_1" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>



                                                <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['slide_pic_3'] ?>" alt="Card image">
                                                          <div class="card-img-overlay d-flex">
                                                            <div class="mt-auto text-center w-100">
                                                              <h3><?php echo $rowS['slide_pic_3_head'] ?></h3>
                                                              <h6 class="card-text mb-4 font-weight-normal"><?php echo $rowS['slide_pic_3_text'] ?></h6>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                      
                                                      
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="slide_3.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label>Slider Picture 3 (873p x 424p)</label>
                                                                    <input type="file" name="slide_pic_3" id="slide_pic_3" class="form-control">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="slide_pic_3_head">Slider 3 Header</label>
                                                                    <input name="slide_pic_3_head" type="text" class="form-control" id="slide_pic_3_head" placeholder="Slider Picture 1 Heading" value="<?php echo $rowS['slide_pic_3_head'] ?>" required>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="slide_pic_3_text">Slider 3 Text</label>
                                                                    <textarea class="form-control" name="slide_pic_3_text" id="slide_pic_3_text" cols="30" rows="4" placeholder="Slider Picture 1 Text"><?php echo $rowS['slide_pic_3_text'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'slide_pic_3_text' );
                                                                    </script>
                                                                </div>
                                                             

                                                                <button type="submit" name="slider_1" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>




                                            </div>
                                        </div>
                                    </div>
                                </div>





                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">School Logos</h3></td><br>
                                            
                                            <div class="row">
                                                
                                              <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['logo_main']; ?>" alt="<?php echo $rowS['name']. " Logo" ?>">
                                                          
                                                        </div>
                                                      </div>
                                                      
                                                    </div>

                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="logo_main.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label>Main Logo (300p x 48p) (PNG only)</label>
                                                                    <input type="file" name="logo_main" id="logo_main" class="form-control">
                                                                </div>

                                                                <button type="submit" name="main_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div><hr>
                                          


                                                <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['logo_small']; ?>" alt="<?php echo $rowS['name']. " Logo" ?>">
                                                          
                                                        </div>
                                                      </div>
                                                      
                                                    </div>

                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="logo_small.php" method="post" enctype="multipart/form-data">
                                                                
                                                                <div class="form-group">
                                                                    <label>Small Logo (179p x 38p) (PNG only)</label>
                                                                    <input type="file" name="logo_small" id="logo_small" class="form-control">
                                                                </div>

                                                                <button type="submit" name="logo_small_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div><hr>



                                                <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['favicon']; ?>" alt="<?php echo $rowS['name']. " Favicon" ?>">
                                                          
                                                        </div>
                                                      </div>
                                                      
                                                    </div>

                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="favicon.php" method="post" enctype="multipart/form-data">
                                                            
                                                                <div class="form-group">
                                                                    <label>Favicon (128p x 128p) (ICO only)</label>
                                                                    <input type="file" name="favicon" id="favicon" class="form-control">
                                                                </div>

                                                                <button type="submit" name="favicon_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>



                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">Contact Details</h3></td><br>
                                            
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="contacts.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label for="phone_main">School Main Phone</label>
                                                                    <input name="phone_main" type="tel" class="form-control" id="phone_main" placeholder="School Main Phone" value="<?php echo $rowS['phone_main'] ?>" required>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="phone_second">School Second Phone</label>
                                                                    <input name="phone_second" type="tel" class="form-control" id="phone_second" placeholder="School Second Phone" value="<?php echo $rowS['phone_second'] ?>" >
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="email">School Email</label>
                                                                    <input name="email" type="email" class="form-control" id="email" placeholder="Email" value="<?php echo $rowS['email'] ?>" required>
                                                                </div>

                                                                <button type="submit" name="contact_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">Social Media Links</h3></td><br>
                                            
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="socials.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label for="facebook">Facebook</label>
                                                                    <input name="facebook" type="tel" class="form-control" id="facebook" placeholder="Facebook Link" value="<?php echo $rowS['facebook'] ?>">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="instagram">Instagram</label>
                                                                    <input name="instagram" type="tel" class="form-control" id="instagram" placeholder="Instagram Link" value="<?php echo $rowS['instagram'] ?>">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="whatsapp">Whatsapp</label>
                                                                    <input name="whatsapp" type="tel" class="form-control" id="whatsapp" placeholder="Whatsapp Number" value="<?php echo $rowS['whatsapp'] ?>" required>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="linkedin">LinkedIn</label>
                                                                    <input name="linkedin" type="tel" class="form-control" id="linkedin" placeholder="LinkedIn Link" value="<?php echo $rowS['linkedin'] ?>">
                                                                </div>
                                                                

                                                                <button type="submit" name="social_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>




                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">Boarding Life</h3></td><br>
                                            
                                            <div class="row">
                                                
                                              <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['boarding_life_pic']; ?>" alt="Boarding Life at <?php echo $rowS['name'] ?>">
                                                          
                                                        </div>
                                                      </div>
                                                      
                                                      
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="boarding.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label>Boarding Life Picture (840p x 505p)</label>
                                                                    <input type="file" name="boarding_life_pic" id="boarding_life_pic" class="form-control" >
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="boarding_life">Boarding Life Article</label>
                                                                    <textarea class="form-control" name="boarding_life" id="boarding_life" cols="30" rows="4" placeholder="Boarding Life Text"><?php echo $rowS['boarding_life'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'boarding_life' );
                                                                    </script>
                                                                </div>

                                                                <button type="submit" name="boarding_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">Our Identity</h3></td><br>
                                            
                                            <div class="row">
                                                
                                              <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['identity_pic']; ?>" alt="<?php echo $rowS['name'] ?> Identity" >
                                                          
                                                        </div>
                                                      </div>
                                                      
                                                      
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="identity.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label>Our Identity Picture (740p x 550p)</label>
                                                                    <input type="file" name="identity_pic" id="identity_pic" class="form-control">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="identity">Our Identity Article</label>
                                                                    <textarea class="form-control" name="identity" id="identity" cols="30" rows="4" placeholder="Our Identity Article"><?php echo $rowS['identity'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'identity' );
                                                                    </script>
                                                                </div>

                                                                <button type="submit" name="identity_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>




                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">School Objectives</h3></td><br>
                                            
                                            <div class="row">
                                                
                                              <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['objectives_pic_1']; ?>" alt="<?php echo $rowS['name'] ?> Objectives Picture" >
                                                          
                                                        </div>
                                                      </div>
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['objectives_pic_2']; ?>" alt="<?php echo $rowS['name'] ?> Objectives Picture" >
                                                          
                                                        </div>
                                                      </div>
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['objectives_pic_3']; ?>" alt="<?php echo $rowS['name'] ?> Objectives Picture" >
                                                          
                                                        </div>
                                                      </div>
                                                      
                                                      
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="objectives.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label>School Objectives Picture 1 (370p x 275p)</label>
                                                                    <input type="file" name="objectives_pic_1" id="objectives_pic_1" class="form-control">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label>School Objectives Picture 2 (175p x 175p)</label>
                                                                    <input type="file" name="objectives_pic_2" id="objectives_pic_2" class="form-control">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label>School Objectives Picture 3 (175p x 175p)</label>
                                                                    <input type="file" name="objectives_pic_3" id="objectives_pic_3" class="form-control">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="objectives">School Objectives Article</label>
                                                                    <textarea class="form-control" name="objectives" id="objectives" cols="30" rows="20" placeholder="School Objectives Article"><?php echo $rowS['objectives'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'objectives' );
                                                                    </script>
                                                                </div>

                                                                <button type="submit" name="objectives_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>




                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">Our Leadership</h3></td><br>
                                            
                                            <div class="row">
                                                
                                              <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['leadership_pic']; ?>" alt="<?php echo $rowS['name'] ?> Leadership" >
                                                          
                                                        </div>
                                                      </div>
                                                      
                                                      
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="leadership.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label>Our Leadership Picture (740p x 940p)</label>
                                                                    <input type="file" name="leadership_pic" id="leadership_pic" class="form-control">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="leadership">Our Leadership Article</label>
                                                                    <textarea class="form-control" name="leadership" id="leadership" cols="30" rows="4" placeholder="Our Leadership Article"><?php echo $rowS['leadership'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'leadership' );
                                                                    </script>
                                                                </div>

                                                                <button type="submit" name="leadership_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>




                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">Our Mission</h3></td><br>
                                            
                                            <div class="row">
                                                
                                              <div class="col-lg-6 stretch-card">
                                                <div class="card">
                                                    <div class="">
                                                      <div class="item">
                                                        <div class="card text-white">
                                                          <img class="card-img" src="../../../../settings/<?php echo $rowS['mission_pic']; ?>" alt="<?php echo $rowS['name'] ?> Mission" >
                                                          
                                                        </div>
                                                      </div>
                                                      
                                                      
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="col-lg-6 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="mission.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label>Our Mission Pic (870p x 370p)</label>
                                                                    <input type="file" name="mission_pic" id="mission_pic" class="form-control">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="mission">Our Mission Article</label>
                                                                    <textarea class="form-control" name="mission" id="mission" cols="30" rows="7" placeholder="Our Mission Article"><?php echo $rowS['mission'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'mission' );
                                                                    </script>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="message">Director Message Article</label>
                                                                    <textarea class="form-control" name="message" id="message" cols="30" rows="10" placeholder="Director Message Article"><?php echo $rowS['message'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'message' );
                                                                    </script>
                                                                </div>

                                                                <button type="submit" name="mission_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="card-title">Admission</h3></td><br>
                                            
                                            <div class="row">
                                                
                                              
                                              <div class="col-lg-12 grid-margin stretch-card">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                              <form class="forms-sample" action="admission.php" method="post" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <label for="admission">Admission Steps</label>
                                                                    <textarea class="form-control" name="admission" id="mission" cols="30" rows="7" placeholder="Our Admission Article"><?php echo $rowS['admission'] ?></textarea>
                                                                    <script>
                                                                        CKEDITOR.replace( 'admission' );
                                                                    </script>
                                                                </div>
                                                                

                                                                <button type="submit" name="admission_send" class="btn btn-primary mr-2">Submit</button>
                                                              </form>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>




            <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php $year=date("Y"); echo $year; ?>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="far fa-heart text-danger"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <script src="../../vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/misc.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="../../js/data-table.js"></script>
  <!-- End custom js for this page-->
</body>
<?php } else { 
        session_destroy();
        header("Location:../../index.php");
    } ?>

</html>
