<?php

session_start();
include '../../database/connect.php' ;
$term = $_REQUEST['term'];
$year = $_REQUEST['year'];
$test_number = $_REQUEST['test_number'];

// Subject Statistics
  
$dataGrade = array();
$qGrade = mysqli_query($con, "SELECT * from grade ORDER BY grade ASC");
while($rowGrade=mysqli_fetch_assoc($qGrade)){
    array_push($dataGrade,$rowGrade);
}
$dataClasses = array();
$qClasses = mysqli_query($con, "SELECT * from classes ORDER BY class ASC");
while($rowClasses=mysqli_fetch_assoc($qClasses)){
    array_push($dataClasses,$rowClasses);
}
foreach ($dataGrade as $dGrade){
    foreach ($dataClasses as $dClasses){
        $dataSubjects = array();
        $qSubjects = mysqli_query($con, "SELECT * from subs WHERE form='".$dGrade['grade']."' AND class='".$dClasses['class']."' ORDER BY subject ASC");
        while($rowSubjects=mysqli_fetch_assoc($qSubjects)){
            array_push($dataSubjects,$rowSubjects);
        }
        foreach($dataSubjects as $dSubject){
            $end = mysqli_query($con, "SELECT COUNT(id) FROM end_test WHERE test_number='".$test_number."' AND year='".$year."' AND term='".$term."' AND subject='".$dSubject['subject']."' AND form='".$dGrade['grade']."' AND class='".$dClasses['class']."'");
            $rowEnd=mysqli_fetch_array($end);
            $totalEnd = $rowEnd[0];
    
            $passed = mysqli_query($con, "SELECT COUNT(id) FROM end_test WHERE test_number='".$test_number."' AND year='".$year."' AND term='".$term."' AND subject='".$dSubject['subject']."' AND form='".$dGrade['grade']."' AND mark>49 AND class='".$dClasses['class']."'");
            $rowPassed=mysqli_fetch_array($passed);
            $totalPassed = $rowPassed[0];
    
            $year2 = $year-1;
            $number=mysqli_query($con, "SELECT * FROM percent_test WHERE test_number='".$test_number."' AND form='".$dGrade['grade']."' AND subject='".$dSubject['subject']."' AND term='".$term."' AND year='".$year2."' AND class='".$dClasses['class']."'");
            $row=mysqli_fetch_assoc($number);
    
            if (isset($row['number'])){
                $number = $row['number']+1;
            } else{
                $number=1;
            }
            $percent_previous = $row['percent_previous'];
            $class = $dClasses['class'];
            
            $q = mysqli_query($con, "INSERT into percent_test (number, test_number, form, term, class, year, subject, total_students, passed, percent_previous) values ('".$number."','".$test_number."','".$dGrade['grade']."','".$term."','".$class."','".$year."','".$dSubject['subject']."','".$totalEnd."','".$totalPassed."','".$row['percent_passed']."')");
            
        }
    }
    
}
$q_update=mysqli_query($con, "UPDATE publishtest set generate=1 where id='".$_REQUEST['id']."'");

// $dataTC = array();
// $qTC = mysqli_query($con, "SELECT * from classes");
// while($rowTC=mysqli_fetch_assoc($qTC)){
//     array_push($dataTC,$rowTC);
// }
// $dataTF = array();
// $qTF = mysqli_query($con, "SELECT * from grade");
// while($rowTF=mysqli_fetch_assoc($qTF)){
//     array_push($dataTF,$rowTF);
// }
// foreach ($dataTF as $dTF) {
//     foreach ($dataTC as $dTC) {
//         $school = mysqli_query($con, "SELECT COUNT(id) FROM users WHERE class='".$dTC['class']."' AND form='".$dTF['grade']."' AND rank>6");
//         $rowSchool=mysqli_fetch_array($school);
//         $totalSchool = $rowSchool[0];  
//         $tc = mysqli_query($con, "INSERT INTO total_class (total, class, form, year, term) values ('".$totalSchool."','".$dTC['class']."','".$dTF['grade']."','".$year."','".$term."')");  
//     }
// }

// CLASS STATISTICS FOR FORM 1-4.

// $dataStudents = array();
// $qStudents = mysqli_query($con, "SELECT * from users WHERE rank>6 AND form<5 ORDER BY form ASC");
// while($rowStudents=mysqli_fetch_assoc($qStudents)){
//     array_push($dataStudents,$rowStudents);
// }

// foreach ($dataStudents as $dStudents) {

//     // $qStudents = mysqli_query($con, "SELECT * FROM end_test WHERE name='".$dStudents['name']."' AND surname='".$dStudents['surname']."' AND mark>50");
//     $passedStudent = mysqli_query($con, "SELECT COUNT(id) FROM end_test WHERE sname='".$dStudents['name']."' AND ssurname='".$dStudents['surname']."' AND mark>49 AND form='".$dStudents['form']."' AND class='".$dStudents['class']."' AND term='".$term."' AND year='".$year."'");
//     $rowPassedStudent=mysqli_fetch_array($passedStudent);
//     $totalPassedStudent = $rowPassedStudent[0];

    
//     $number=mysqli_query($con, "SELECT * FROM total_class WHERE form='".$dStudents['form']."' AND term='".$term."' AND year='".$year."' AND class='".$dStudents['class']."'");
//     $row=mysqli_fetch_assoc($number);

//     $totall = $row['total'];
    
    

//     if ($totalPassedStudent>4){
//         echo $totall.": ";
//         echo $totalPassedStudent.", ";

//         $form = $dStudents['form'];
//         $class = $dStudents['class'];

//         $year = $year-1;
//         $numberSchools=mysqli_query($con, "SELECT * FROM percent_class WHERE term='".$term."' AND year='".$year."' AND class='".$dStudents['class']."' AND form='".$dStudents['form']."'");
//         $rowSchool=mysqli_fetch_assoc($numberSchools);

//         if (mysqli_num_rows($numberSchools)>0){
//             $numberSchool = $rowSchool['number']+1;
//         } else{
//             $numberSchool=1;
//         }
//         $percent_previous_school = $rowSchool['percent_passed'];

//         $qStudent = mysqli_query($con, "SELECT * FROM percent_class WHERE year='".$year."' AND term='".$term."' AND class='".$dStudents['class']."' AND form='".$dStudents['form']."'");
//         $rowStd=mysqli_fetch_assoc($qStudent);

//         if ($rowStd>0){
//             echo ": Mune chinhu Pass";
//             $passedSchool = $rowStd['passed']+1;
//             $q = mysqli_query($con, "UPDATE percent_class SET passed='".$passedSchool."'");
//         } else{
//             echo ": Hamuna chinhu Pass";
//             $q = mysqli_query($con, "INSERT INTO percent_class (number, form, term, class, year, total_students, passed, percent_previous) values ('".$numberSchool."', '".$form."', '".$term."', '".$class."', '".$year."', '".$totall."', 1, '".$percent_previous_school."')");
//         }
        
//     } else {
//         echo $totall.": ";
//         echo $totalPassedStudent.", ";
        
//         $form = $dStudents['form'];
//         $class = $dStudents['class'];

//         $year = $year-1;
//         $numberSchools=mysqli_query($con, "SELECT * FROM percent_class WHERE term='".$term."' AND year='".$year."' AND class='".$dStudents['class']."' AND form='".$dStudents['form']."'");
//         $rowSchool=mysqli_fetch_assoc($numberSchools);

//         if (mysqli_num_rows($numberSchools)>0){
//             $numberSchool = $rowSchool['number']+1;
//         } else{
//             $numberSchool=1;
//         }
//         $percent_previous_school = $rowSchool['percent_passed'];

//         $qStudent = mysqli_query($con, "SELECT * FROM percent_class WHERE year='".$year."' AND term='".$term."' AND class='".$dStudents['class']."' AND form='".$dStudents['form']."'");
//         $rowStd=mysqli_fetch_assoc($qStudent);

//         if ($rowStd>0){
//             echo ": Mune chinhu Fail";
//             $passedSchool = $rowStd['passed']+0;
//             $q = mysqli_query($con, "UPDATE percent_class SET passed='".$passedSchool."'");
//         } else{
//             echo ": Hamuna chinhu Fail";
//             $q = mysqli_query($con, "INSERT INTO percent_class (number, form, term, class, year, total_students, passed, percent_previous) values ('".$numberSchool."', '".$form."', '".$term."', '".$class."', '".$year."', '".$totall."', 0, '".$percent_previous_school."')");
//         }
//     }
// }


// CLASS STATISTICS FOR FORM 5 AND 6.

// $dataStudents2 = array();
// $qStudents2 = mysqli_query($con, "SELECT * from users WHERE rank>6 AND form>4 ORDER BY form ASC");
// while($rowStudents2=mysqli_fetch_assoc($qStudents2)){
//     array_push($dataStudents2,$rowStudents2);
// }

// foreach ($dataStudents2 as $dStudents2) {

//     // $qStudents = mysqli_query($con, "SELECT * FROM end_test WHERE name='".$dStudents['name']."' AND surname='".$dStudents['surname']."' AND mark>50");
//     $passedStudent2 = mysqli_query($con, "SELECT COUNT(id) FROM end_test WHERE sname='".$dStudents2['name']."' AND ssurname='".$dStudents2['surname']."' AND mark>39 AND form='".$dStudents2['form']."' AND class='".$dStudents2['class']."' AND term='".$term."' AND year='".$year."'");
//     $rowPassedStudent2=mysqli_fetch_array($passedStudent2);
//     $totalPassedStudent2 = $rowPassedStudent2[0];

    
//     $number2=mysqli_query($con, "SELECT * FROM total_class WHERE form='".$dStudents2['form']."' AND term='".$term."' AND year='".$year."' AND class='".$dStudents2['class']."'");
//     $row2=mysqli_fetch_assoc($number2);

//     $totall2 = $row2['total'];
    
    

//     if ($totalPassedStudent2>1){
//         echo $totall2.": ";
//         echo $totalPassedStudent2.", ";

//         $form = $dStudents2['form'];
//         $class = $dStudents2['class'];

//         $year2 = $year-1;
//         $numberSchools2=mysqli_query($con, "SELECT * FROM percent_class WHERE term='".$term."' AND year='".$year2."' AND class='".$dStudents2['class']."' AND form='".$dStudents2['form']."'");
//         $rowSchool2=mysqli_fetch_assoc($numberSchools2);

//         if (mysqli_num_rows($numberSchools2)>0){
//             $numberSchool2 = $rowSchool2['number']+1;
//         } else{
//             $numberSchool2=1;
//         }
//         $percent_previous_school2 = $rowSchool2['percent_passed'];

//         $qStudent2 = mysqli_query($con, "SELECT * FROM percent_class WHERE year='".$year."' AND term='".$term."' AND class='".$dStudents2['class']."' AND form='".$dStudents2['form']."'");
//         $rowStd2=mysqli_fetch_assoc($qStudent2);

//         if ($rowStd2>0){
//             echo ": Mune chinhu";
//             $passedSchool2 = $rowStd2['passed']+1;
//             $q2 = mysqli_query($con, "UPDATE percent_class SET passed='".$passedSchool2."'");
//         } else{
//             echo ": Hamuna chinhu";
//             $q2 = mysqli_query($con, "INSERT INTO percent_class (number, form, term, class, year, total_students, passed, percent_previous) values ('".$numberSchool2."', '".$form."', '".$term."', '".$class."', '".$year."', '".$totall2."', 1, '".$percent_previous_school2."')");
//         }
        
//     } else {
//         $form = $dStudents2['form'];
//         $class = $dStudents2['class'];

//         $year2 = $year-1;
//         $numberSchools2=mysqli_query($con, "SELECT * FROM percent_class WHERE term='".$term."' AND year='".$year2."' AND class='".$dStudents2['class']."' AND form='".$dStudents2['form']."'");
//         $rowSchool2=mysqli_fetch_assoc($numberSchools2);

//         if (mysqli_num_rows($numberSchools2)>0){
//             $numberSchool2 = $rowSchool2['number']+1;
//         } else{
//             $numberSchool2=1;
//         }
//         $percent_previous_school2 = $rowSchool2['percent_passed'];

//         $qStudent2 = mysqli_query($con, "SELECT * FROM percent_class WHERE year='".$year."' AND term='".$term."' AND class='".$dStudents2['class']."' AND form='".$dStudents2['form']."'");
//         $rowStd2=mysqli_fetch_assoc($qStudent2);

//         if ($rowStd2>0){
//             echo ": Mune chinhu";
//             $passedSchool2 = $rowStd2['passed']+0;
//             $q2 = mysqli_query($con, "UPDATE percent_class SET passed='".$passedSchool2."'");
//         } else{
//             echo ": Hamuna chinhu";
//             $q2 = mysqli_query($con, "INSERT INTO percent_class (number, form, term, class, year, total_students, passed, percent_previous) values ('".$numberSchool2."', '".$form."', '".$term."', '".$class."', '".$year."', '".$totall2."', 0, '".$percent_previous_school2."')");
//         }
//     }
// }


if ($q){
    header("Location:publishT.php?success=Successfully Generated Results Statistics. Click the Statistics link to view the Statistics.");     
} else {
    header("Location:publishT.php?error=Failed to Generate Statisctics");
}





?>