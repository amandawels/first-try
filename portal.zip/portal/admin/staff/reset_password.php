<?php

session_start();
include '../../../../database/connect.php';

$id = $_REQUEST['id'];
$q = mysqli_query($con, "UPDATE users SET password='blank' WHERE id='".$id."'");

if ($q) {
    header("Location:all-staff.php?success=Reset Password Successfully");
}
else {
    header("Location:all-staff.php?error=Failed to reset password");
}
?>