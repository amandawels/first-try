<?php

session_start();
include '../../../../database/connect.php';

$id = $_REQUEST['id'];
$q = mysqli_query($con, "UPDATE users SET password='blank' WHERE id='".$id."'");

if ($q) {
    header("Location:view-student.php?success=Reset Student Password Successfully&&id=$id");
}
else {
    header("Location:view-student.php?error=Failed to reset password&&id=$id");
}
?>