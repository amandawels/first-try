<?php include "../../path.php";
session_start();
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    if($_SESSION['user_data']['rank']!=4){
        if($_SESSION['user_data']['rank']!=1){
            session_destroy();
            header("Location:../../logout.php");
        }
        
    }

    $today_date = date("Y-m-d");

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);

    $dataCalendar = array();
    $qCalendar = mysqli_query($con, "SELECT * FROM calendar WHERE '".$today_date."' <= date ORDER BY date ASC LIMIT 5");
    while($rowCalendar=mysqli_fetch_assoc($qCalendar)){
        array_push($dataCalendar,$rowCalendar);
    }

    $dataN = array();
    $qN = mysqli_query($con, "SELECT * FROM notices ORDER BY date ASC LIMIT 5");
    while($rowN=mysqli_fetch_assoc($qN)){
        array_push($dataN,$rowN);
     }

    


    $form = $_REQUEST['form'];
    $term = $_REQUEST['term'];
    $date = $_REQUEST['date'];

$data = array();
$q = mysqli_query($con, "SELECT * FROM arrears WHERE form='".$form."' AND term='".$term."' AND date='".$date."'");
while($row=mysqli_fetch_assoc($q)){
    array_push($data,$row);
}
?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.urbanui.com/melody/template/pages/tables/data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Sep 2018 06:08:40 GMT -->
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $rowS['short_name'] ?> Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/iconfonts/font-awesome/css/all.min.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../../../settings/<?php echo $rowS['favicon'] ?>" />
</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
            <!-- Open Header -->

<nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row default-layout-navbar">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo" href="../../home.php"><img src="../../../../settings/<?php echo $rowS['logo_main'] ?>" alt="logo"/></a>
        <a class="navbar-brand brand-logo-mini" href="../../home.php"><img src="../../images/logo-mini.png" alt="logo"/></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-stretch">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="fas fa-bars"></span>
        </button>
        
        <ul class="navbar-nav navbar-nav-right">
          
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              <img src="<?php echo ("../../../../images/users/staff/").($_SESSION['user_data']['pic']) ?>" alt="profile"/>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <a class="dropdown-item" href="../profile/profile.php">
                <i class="fas fa-cog text-primary"></i>
                Settings
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="../../logout.php">
                <i class="fas fa-power-off text-primary"></i>
                Logout
              </a>
            </div>
          </li>
          <li class="nav-item nav-settings">
            <a class="nav-link" href="#">
              <i class="fas fa-ellipsis-h"></i>
            </a>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="fas fa-bars"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      
      <div id="right-sidebar" class="settings-panel">
        <i class="settings-close fa fa-times"></i>
        <ul class="nav nav-tabs" id="setting-panel" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="todo-tab" data-toggle="tab" href="#todo-section" role="tab" aria-controls="todo-section" aria-expanded="true">UPCOMING EVENTS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="chats-tab" data-toggle="tab" href="#chats-section" role="tab" aria-controls="chats-section">NOTICES</a>
          </li>
        </ul>

        <div class="tab-content" id="setting-content">
          <div class="tab-pane fade show active scroll-wrapper" id="todo-section" role="tabpanel" aria-labelledby="todo-section">
            <div class="add-items d-flex px-3 mb-0">
              <!-- <form class="form w-100">
                <div class="form-group d-flex">
                  <input type="text" class="form-control todo-list-input" placeholder="Add To-do">
                  <button type="submit" class="add btn btn-primary todo-list-add-btn" id="add-task-todo">Add</button>
                </div>
              </form> -->
            </div>
            <?php foreach ($dataCalendar as $dCalendar): ?>
            <div class="events py-4 border-bottom px-3">
              <div class="wrapper d-flex mb-2">
                <div class="tg-widgetcontent">
                  <div class="item">
                    <div id="tg-comments" class="tg-comments">
                        <div class="tg-comment">
                          <figure><a href="#"></a></figure>
                          <div class="tg-commentcontent">
                            <div class="">
                              <span><i class="fas fa-calendar"></i> <?php $date = $dCalendar['date']; echo date("F d, Y", strtotime($date)); ?></span>
                              <h5><?php echo $dCalendar['title'] ?></h5>
                            </div>
                          </div>
                        </div>		
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
            

          </div>

          <!-- To do section tab ends -->
          <div class="tab-pane fade" id="chats-section" role="tabpanel" aria-labelledby="chats-section">

            <ul class="chat-list">
              <?php foreach ($dataN as $dNotice): ?>
              <li class="list active">
                <div class="profile"><i class="fas fa-calendar"></i></div>
                <div class="info">
                  <p><?php echo $dNotice['title'] ?></p>
                </div>
              </li><br>
              <?php endforeach; ?>
              
            </ul>
          </div>
          <!-- chat tab ends -->
        </div>
      </div>
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">

          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="profile-image">
                <img src="<?php echo ("../../../../images/users/staff/").($_SESSION['user_data']['pic']); ?>" alt="image"/>
              </div>
              <div class="profile-name">
                <p class="name">
                  <?php echo($_SESSION['user_data']['title']." ".$_SESSION['user_data']['surname']); ?>
                </p>
                <p class="designation">
                  <?php $rank=$_SESSION['user_data']['rank']; if ($rank==1){echo "Director";} else if($rank==2){echo "Principal";} else if($rank==3){echo "H.O.D";} else if($rank==4){echo "Administration";} else if($rank==5){echo "Teacher";} else {echo "Non-Teaching Staff";} ?>
                </p>
              </div>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../../home.php">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../students/search.php">
              <i class="fa fa-search menu-icon"></i>
              <span class="menu-title">Search Students</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#publish" aria-expanded="false" aria-controls="publish">
              <i class="fa fa-book menu-icon"></i>
              <span class="menu-title">Publish Results</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="publish">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../../publish.php">End of Term</a></li>
                <li class="nav-item"> <a class="nav-link" href="../../publishT.php">Test Results</a></li>
              </ul>
            </div>
          </li>
          
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#statistics" aria-expanded="false" aria-controls="statistics">
              <i class="fa fa-book menu-icon"></i>
              <span class="menu-title">Statistics</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="statistics">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../statistics/select-stats.php">End of Term</a></li>
                <li class="nav-item"> <a class="nav-link" href="../statisticsTest/select-stats.php">Test Results</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#students" aria-expanded="false" aria-controls="students">
              <i class="fa fa-user menu-icon"></i>
              <span class="menu-title">Students</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="students">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../students/see-students.php">go to class</a></li>
                <li class="nav-item"> <a class="nav-link" href="../students/all-students.php">Manage Students</a></li>
                <li class="nav-item"> <a class="nav-link" href="../students/cArrears.php">Arrears</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#staff" aria-expanded="false" aria-controls="staff">
              <i class="fa fa-user menu-icon"></i>
              <span class="menu-title">Staff</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="staff">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../staff/add-staff.php">Add Staff</a></li>
                <li class="nav-item"> <a class="nav-link" href="../staff/all-staff.php">Manage Staff</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#notice" aria-expanded="false" aria-controls="notice">
              <i class="fa fa-bell menu-icon"></i>
              <span class="menu-title">Notices</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="notice">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../notice/add-notice.php">Add Notice</a></li>
                <li class="nav-item"> <a class="nav-link" href="../notice/all-notice.php">Manage Notices</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#calendar" aria-expanded="false" aria-controls="calendar">
              <i class="fa fa-calendar menu-icon"></i>
              <span class="menu-title">Calendar</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="calendar">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../calendar/add-calendar.php">Add Upcoming Event</a></li>
                <li class="nav-item"> <a class="nav-link" href="../calendar/all-calendar.php">Manage Calendar</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#news" aria-expanded="false" aria-controls="news">
              <i class="fas fa-clipboard-list menu-icon"></i>
              <span class="menu-title">News</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="news">
              <ul class="nav flex-column sub-menu">
              <li class="nav-item"> <a class="nav-link" href="../news/add-news.php">Add News</a></li>
                <li class="nav-item"> <a class="nav-link" href="../news/all-news.php">Manage News</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#gallery" aria-expanded="false" aria-controls="gallery">
              <i class="fa fa-image menu-icon"></i>
              <span class="menu-title">Gallery</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="gallery">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../gallery/add-picture.php">Add Pictures</a></li>
                <li class="nav-item"> <a class="nav-link" href="../gallery/all-pictures.php">Manage Gallery</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#department" aria-expanded="false" aria-controls="department">
              <i class="fas fa-cube menu-icon"></i>
              <span class="menu-title">Departments/Clubs</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="department">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../department/add-department.php">Add Department/Club</a></li>
                <li class="nav-item"> <a class="nav-link" href="../department/all-departments.php">Manage Departments/Clubs</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#downloads" aria-expanded="false" aria-controls="downloads">
              <i class="fa fa-download menu-icon"></i>
              <span class="menu-title">Downloads</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="downloads">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../downloads/add-download.php">Upload File</a></li>
                <li class="nav-item"> <a class="nav-link" href="../downloads/all-downloads.php">Manage Downloads</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#jobs" aria-expanded="false" aria-controls="jobs">
              <i class="fa fa-briefcase menu-icon"></i>
              <span class="menu-title">Vacants</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="jobs">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../jobs/add-job.php">Upload Vacant</a></li>
                <li class="nav-item"> <a class="nav-link" href="../jobs/all-job.php">Manage Vacants</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#subjects" aria-expanded="false" aria-controls="subjects">
              <i class="fa fa-book menu-icon"></i>
              <span class="menu-title">Subjects</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="subjects">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="../subjects/add-subject.php">Add Subject</a></li>
                <li class="nav-item"> <a class="nav-link" href="../subjects/select-class.php">Manage Subjects</a></li>
              </ul>
            </div>
          </li>


          <!-- <li class="nav-item">
            <a class="nav-link" href="../statistics/select-stats.php">
              <i class="fa fa-book menu-icon"></i>
              <span class="menu-title">Statistics</span>
            </a>
          </li> -->

          
          <li class="nav-item">
            <a class="nav-link" href="../emails/emails.php">
              <i class="fa fa-envelope menu-icon"></i>
              <span class="menu-title">Emails</span>
            </a>
          </li>

          
          <li class="nav-item">
            <a class="nav-link" href="../sb/sb.php">
              <i class="fa fa-envelope menu-icon"></i>
              <span class="menu-title">Suggestion Box</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../profile/profile.php">
              <i class="fa fa-cog menu-icon"></i>
              <span class="menu-title">Settings</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../../logout.php">
              <i class="fa fa-power-off menu-icon"></i>
              <span class="menu-title">Logout</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../../../../index.php">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Go to Public</span>
            </a>
          </li>

          <br><br><br>

          
        </ul>
      </nav>

      <!-- Close Header -->
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
            <div class="page-header">
                <h3 class="page-title">
                Form <?php echo $_REQUEST['form'] ?> Students Arrears for Term <?php echo $_REQUEST['term'].", ".$_REQUEST['date'] ?>
                </h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="see-students.php">Select Class</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Form <?php echo $_REQUEST['form'] ?></li>
                    </ol>
                </nav>
            </div>

            <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-12">
                  <div class="row">
                      <?php if(isset($_REQUEST['success'])) { ?>
                          <div class="col-lg-12">
                              <span class="alert alert-success alert-block" style="display: block;"><?php echo $_REQUEST['success']; ?></span>
                          </div>
                      <?php } ?>
                  </div>  
                  <div class="row">
                      <?php if(isset($_REQUEST['error'])) { ?>
                          <div class="col-lg-12">
                              <span class="alert alert-danger alert-block" style="display: block;"><?php echo $_REQUEST['error']; ?></span>
                          </div>
                      <?php } ?>
                  </div>
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th>#</th>
                            <th>Surname</th>
                            <th>Name</th>
                            <th>Arrears</th>
                            <th>Status</th>
                            <th>Manage</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                            foreach($data as $key=>$d) {
                                $qU = mysqli_query($con, "SELECT * from users where id='".$d['student_id']."'");
                                $rowU=mysqli_fetch_assoc($qU)
                        ?>
                        <tr>
                            <td><?php echo $key+1 ?></td>
                            <td><?php echo $d['surname']; ?></td>
                            <td><?php echo $d['name']; ?></td>
                            <td><?php echo "$ ".$d['amount']; ?></td>
                            <td><?php
                                  $is_locked = false;
                                  if(($rowU['rank'])=='8'){
                                      $is_locked = true;
                                  } 
                                  ?>
                                  <?php if(($is_locked)==false) { ?>
                                      <a href="lock-student.php?id=<?php echo $rowU['id']; ?>" class="btn btn-warning">Lock Account</a>
                                  <?php } else { ?>
                                      <a href="unlock-student.php?id=<?php echo $rowU['id']; ?>" class="btn btn-info">Unlock Account</a>
                                <?php } ?>
                            </td>
                            <td>
                              <a href="pay-arrears.php?id=<?php echo $d['id']; ?>&student_id=<?php echo $rowU['id']; ?>" class="btn btn-outline-primary">Settle Arrears</a>
                            </td>
                        </tr>
                        <?php } ?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php $year=date("Y"); echo $year; ?>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="far fa-heart text-danger"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <script src="../../vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/misc.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="../../js/data-table.js"></script>
  <!-- End custom js for this page-->
</body>
<?php } else { 
        session_destroy();
        header("Location:../../index.php");
    } ?>

<!-- Mirrored from www.urbanui.com/melody/template/pages/tables/data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Sep 2018 06:08:41 GMT -->
</html>
