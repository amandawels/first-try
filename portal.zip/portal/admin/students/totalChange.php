<?php
session_start();
include '../../../../database/connect.php';

if(count($_POST)>0) {
    
    mysqli_query($con, "UPDATE users SET total_school='".$rowTotal['lower']."' WHERE form<5");
    mysqli_query($con, "UPDATE users SET total_school='".$rowTotal['upper']."' WHERE form>4");
    mysqli_query($con, "UPDATE users SET boarding='".$rowTotal['boarding']."' WHERE intake='boarder'");

    // mysqli_query($con, "UPDATE users SET total_school='".$_REQUEST['lower']."' WHERE form='4'");
    // mysqli_query($con, "UPDATE users SET total_school='".$_REQUEST['upper']."' WHERE form='5'");
    // mysqli_query($con, "UPDATE users SET total_school='".$_REQUEST['upper']."' WHERE form='6'");

    // mysqli_query($con, "UPDATE users SET total='".$_REQUEST['blower']."' WHERE form='1' and intake='boarder'");
    // mysqli_query($con, "UPDATE users SET total='".$_REQUEST['blower']."' WHERE form='2' and intake='boarder'");
    // mysqli_query($con, "UPDATE users SET total='".$_REQUEST['blower']."' WHERE form='3' and intake='boarder'");
    // mysqli_query($con, "UPDATE users SET total='".$_REQUEST['blower']."' WHERE form='4' and intake='boarder'");
    // mysqli_query($con, "UPDATE users SET total='".$_REQUEST['bupper']."' WHERE form='5' and intake='boarder'");
    // mysqli_query($con, "UPDATE users SET total='".$_REQUEST['bupper']."' WHERE form='6' and intake='boarder'");

    mysqli_query($con, "UPDATE total SET lower='".$_REQUEST['lower']."',upper='".$_REQUEST['upper']."', boarding='".$_REQUEST['boarding']."' WHERE id='1'");
    header("Location:all-students.php?success=Updated Total Fees Successfully");
}

?>