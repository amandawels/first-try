<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:index.php");
}
$title=mysqli_real_escape_string($con,$_REQUEST['title']);
$content=mysqli_real_escape_string($con,$_REQUEST['content']);


$q = mysqli_query($con, "INSERT into notices (title, content) values ('".$title."','".$content."')");
if ($q) {
    header("Location:all-notice.php?success=Added Successfully");
}
else {
    header("Location:all-notice.php?error=Failed to add Notice");
}
?>