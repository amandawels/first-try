<?php
session_start();
include '../../../../database/connect.php';
$subject=mysqli_real_escape_string($con,$_REQUEST['subject']);
$form=mysqli_real_escape_string($con,$_REQUEST['form']);
$class=mysqli_real_escape_string($con,$_REQUEST['class']);


$abb = '';

switch ($subject) {
    case 'english':
        $abb = 'ENG';
        break;
    case 'shona':
        $abb = 'SHONA';
        break;
    case 'maths':
        $abb = 'MATHS';
        break;
    case 'combined_science':
        $abb = 'SCIE';
        break;
    case 'statistics':
        $abb = 'STAT';
        break;
    case 'geography':
        $abb = 'GEO';
        break;
    case 'history':
        $abb = 'HIS';
        break;
    case 'accounts':
        $abb = 'ACC';
        break;
    case 'commerce':
        $abb = 'COMM';
        break;
    case 'heritage':
        $abb = 'HER';
        break;
    case 'icdl':
        $abb = 'ICDL';
        break;
    case 'computer_science':
        $abb = 'COMP';
        break;
    case 'computer_studies':
        $abb = 'COMP';
        break;
    case 'business_studies':
        $abb = 'BSTU';
        break;
    case 'business_enterprise':
        $abb = 'BENT';
        break;
    case 'biology':
        $abb = 'BIO';
        break;
    case 'physics':
        $abb = 'PHY';
        break;
    case 'chemistry':
        $abb = 'CHEM';
        break;
    case 'frs':
        $abb = 'FRS';
        break;
    case 'economics':
        $abb = 'ECO';
        break;
    case 'sociology':
        $abb = 'SOC';
        break;
    case 'shona_literature':
        $abb = 'SHONA_LIT';
        break;
    case 'literature_in_english':
        $abb = 'ENG_LIT';
        break;
    case 'bible_studies':
        $abb = 'BIBLE';
        break;
    case 'Agriculture':
        $abb = 'AGRIC';
        break;
    case 'Divinity':
        $abb = 'DIV';
        break;
    case 'religious_studies':
        $abb = 'RSTU';
        break;
    case 'biblical_studies':
        $abb = 'BIBLIC';
        break;
    case 'technical_graphics':
        $abb = 'TG';
        break;
    case 'woodwork':
        $abb = 'WOOD';
        break;
    case 'music':
        $abb = 'MUSIC';
        break;
    case 'textile_and_design':
        $abb = 'TnD';
        break;
    case 'PE':
        $abb = 'PE';
        break;
    default:
        $abb = '';
}

$q = mysqli_query($con, "INSERT into subs (form, class, subject, abb) values ('".$form."','".$class."','".$subject."','".$abb."')");
if ($q) {
    header("Location:all-subjects.php?success=Added Subject Successfully&form=$form&class=$class");
}
else {
    header("Location:all-subjects.php?error=Failed to add Subject&form=$form&class=$class");
}
?>