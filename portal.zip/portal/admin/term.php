<?php
session_start();
include '../../database/connect.php';


if(count($_POST)>0) {
    mysqli_query($con, "UPDATE users SET term='".$_REQUEST['term']."'");
    mysqli_query($con, "UPDATE term SET term='".$_REQUEST['term']."'");
    header("Location:home.php?success=Updated Term Successfully");
}