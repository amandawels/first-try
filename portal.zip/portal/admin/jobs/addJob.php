<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$title=mysqli_real_escape_string($con,$_REQUEST['title']);
$date=mysqli_real_escape_string($con,$_REQUEST['date']);
$requirements=mysqli_real_escape_string($con,$_REQUEST['requirements']);
$duties=mysqli_real_escape_string($con,$_REQUEST['duties']);


$q = mysqli_query($con, "INSERT into jobs (title, date, requirements, duties) values ('".$title."','".$date."','".$requirements."','".$duties."')");
if ($q) {
    header("Location:all-job.php?success=Added Successfully");
}
else {
    header("Location:all-job.php?error=Failed to add Upcoming Event");
}
?>