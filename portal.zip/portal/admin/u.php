<?php

session_start();
include '../../database/connect.php' ;
$term = $_REQUEST['term'];
$year = $_REQUEST['year'];
$id=$_REQUEST['id'];
$q_update=mysqli_query($con, "UPDATE publish set published=0 where id='".$_REQUEST['id']."'");
$published67=mysqli_query($con, "UPDATE end_marks set publish=0 where year='".$year."' and term='".$term."'");
if (isset($id)){
    header("Location:publish.php?error=Unpublished Results Successfully");    
}


?>