<?php

include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$title=mysqli_real_escape_string($con,$_REQUEST['title']);
$date=mysqli_real_escape_string($con,$_REQUEST['date']);
$content=mysqli_real_escape_string($con,$_REQUEST['content']);

$pic = time() . '_' . $_FILES['pic']['name'];
$destination = "../../../../images/news/" . $pic;
$result = move_uploaded_file($_FILES['pic']['tmp_name'], $destination);

$category=mysqli_real_escape_string($con,$_REQUEST['category']);
$category_name=mysqli_real_escape_string($con,$_REQUEST['category_name']);
$city=mysqli_real_escape_string($con,$_REQUEST['city']);
$country=mysqli_real_escape_string($con,$_REQUEST['country']);

$author_name = mysqli_real_escape_string($con,$_REQUEST['author_name']);

$q = mysqli_query($con, "INSERT into news (author_name, title, date, content, pic, category, category_name, city, country) values ('".$author_name."','".$title."','".$date."','".$content."','".$pic."','".$category."','".$category_name."','".$city."','".$country."')");
if ($q) {
    header("Location:all-news.php?success=Added Successfully");
}
else {
    header("Location:all-news.php?error=Failed to add Event");
}
?>