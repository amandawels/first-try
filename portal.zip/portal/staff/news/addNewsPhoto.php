<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$title=mysqli_real_escape_string($con,$_REQUEST['title']);
$news_id=mysqli_real_escape_string($con,$_REQUEST['news_id']);

$pic = time() . '_' . $_FILES['pic']['name'];
$destination = "../../../../images/gallery/" . $pic;
$result = move_uploaded_file($_FILES['pic']['tmp_name'], $destination);

$author_name = mysqli_real_escape_string($con,$_REQUEST['author_name']);


$q = mysqli_query($con, "INSERT into pics (author_name, title, news_id, pic, category) values ('".$author_name."','".$title."','".$news_id."', '".$pic."', 'News')");
if ($q) {
    header("Location:news-pictures.php?success=Added Successfully. Another one.&news_id=$news_id");
}
else {
    header("Location:news-pictures.php?error=Failed to add news picture. Try Again&news_id=$news_id");
}
?>