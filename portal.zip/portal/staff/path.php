<?php 

define("ROOT_PATH", realpath(dirname(__FILE__)));
define("BASE_URL", "https://cornerstonecollege.ac.zw/portal/staff");

?>