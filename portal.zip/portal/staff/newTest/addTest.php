<?php
session_start();
include '../../../../database/connect.php' ;
if(isset($_SESSION['user_data'])){

    $q1 = mysqli_query($con, "SELECT * FROM users WHERE id='".$_SESSION['user_data']['id']."'");
    $row1 = mysqli_fetch_assoc($q1);

    $data4 = array();
    $q = mysqli_query($con, "SELECT * from users where rank>6 and form='".$_REQUEST['form']."' AND class='".$_REQUEST['class']."'");
    while($row=mysqli_fetch_assoc($q)){
        array_push($data4,$row);
    };


    $year=date("Y");
    $term = $_REQUEST['term'];

    if(count($_POST)>0) {

        foreach ($data4 as $d){
            $id = $d['id'];
            $name = $d['name'];
            $surname = $d['surname'];
            $term = $d['term'];
            $form = $d['form'];
            $class = $d['class'];
            $subject = $_REQUEST['subject'];
            $mark = $_REQUEST[$id.",".$subject."_mark"];
            $test_number = $_REQUEST['test_number'];
            $year=date("Y");
            

            // echo $id." :";
            // echo $term." :";
            // echo $subject." :";
            // echo $mark." :";
            // echo $comment." :endendend:";

            if ($mark>0) {
                $qC = mysqli_query($con, "select * from end_test where student_id='".$id."' and term='".$term."' and form='".$form."' and subject='".$subject."' and test_number='".$test_number."'");
                if (mysqli_num_rows($qC)>0) {
                    $qU = mysqli_query($con, "UPDATE end_test SET mark='".$mark."' WHERE student_id='".$id."' and term='".$term."' and form='".$form."' and subject='".$subject."' and test_number='".$test_number."'");
                } else {
                    $q = mysqli_query($con, "INSERT into end_test (student_id, name, surname, test_number, class, form, term, subject, mark, year) values ('".$id."', '".$name."', '".$surname."', '".$test_number."', '".$class."', '".$form."', '".$term."','".$subject."', '".$mark."', '".$year."')");
                }
                
            }

            $publishTest = mysqli_query($con, "select * from publishtest where test_number='".$test_number."' and term='".$term."' and year='".$year."'");
            if (mysqli_num_rows($publishTest)==0) {
                $pub = mysqli_query($con, "INSERT into publishtest (test_number, term, year) values ('".$test_number."','".$term."', '".$year."')");
            }
            header("Location:class.php?success=Added Results Successfully&form=$form&class=$class&subject=$subject&term=$term&test_number=$test_number");
            
        }
        
        

        
    }
    else {
        $term = $_REQUEST['term'];
        $form = $_REQUEST['form'];
        $class = $_REQUEST['class'];
        $subject = $_REQUEST['subject'];
        $mark = $_REQUEST[$id.",".$subject."_mark"];
        $test_number = $_REQUEST['test_number'];

        header("Location:class.php?error=Failed to add Results&form=$form&class=$class&subject=$subject&term=$term&test_number=$test_number");
    }
   
   
}

?>