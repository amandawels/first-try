<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:index.php");
}
$title=mysqli_real_escape_string($con,$_REQUEST['title']);
$content=mysqli_real_escape_string($con,$_REQUEST['content']);

$author_name = mysqli_real_escape_string($con,$_REQUEST['author_name']);;


$q = mysqli_query($con, "INSERT into notices (author_name, title, content) values ('".$author_name."','".$title."','".$content."')");
if ($q) {
    header("Location:all-notice.php?success=Added Successfully");
}
else {
    header("Location:all-notice.php?error=Failed to add Notice");
}
?>