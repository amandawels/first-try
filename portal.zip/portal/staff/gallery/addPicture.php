<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$title=mysqli_real_escape_string($con,$_REQUEST['title']);
$category=mysqli_real_escape_string($con,$_REQUEST['category']);

$pic = time() . '_' . $_FILES['pic']['name'];
$destination = "../../../images/gallery/" . $pic;
$result = move_uploaded_file($_FILES['pic']['tmp_name'], $destination);

$author_name = mysqli_real_escape_string($con,$_REQUEST['author_name']);;


$q = mysqli_query($con, "INSERT into pics (author_name, title, category, pic) values ('".$author_name."','".$title."', '".$category."', '".$pic."')");
if ($q) {
    header("Location:all-pictures.php?success=Added Successfully");
}
else {
    header("Location:all-pictures.php?error=Failed to upload picture");
}
?>