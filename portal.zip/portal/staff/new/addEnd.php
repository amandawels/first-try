<?php
session_start();
include '../../../../database/connect.php' ;
if(isset($_SESSION['user_data'])){

    $q1 = mysqli_query($con, "SELECT * FROM users WHERE id='".$_SESSION['user_data']['id']."'");
    $row1 = mysqli_fetch_assoc($q1);

    $data4 = array();
    $q = mysqli_query($con, "SELECT * from users where rank>6 and form='".$_REQUEST['form']."' AND class='".$_REQUEST['class']."'");
    while($row=mysqli_fetch_assoc($q)){
        array_push($data4,$row);
    };


    $year = $_REQUEST['year'];
    $term = $_REQUEST['term'];

    if(count($_POST)>0) {

        foreach ($data4 as $d){
            $id = $d['id'];
            $name = $d['name'];
            $surname = $d['surname'];
            $term = $d['term'];
            $form = $d['form'];
            $class = $d['class'];
            $subject = $_REQUEST['subject'];
            $mark = $_REQUEST[$id.",".$subject."_mark"];
            $comment = $_REQUEST[$id.",".$subject."_comment"];

            // echo $id." :";
            // echo $term." :";
            // echo $subject." :";
            // echo $mark." :";
            // echo $comment.":"; 
            // echo $year ."endendend:";

            if ($mark>0) {
                $qC = mysqli_query($con, "select * from end_marks where student_id='".$id."' and term='".$term."' and form='".$form."' and subject='".$subject."' and year='".$year."'");
                if (mysqli_num_rows($qC)>0) {
                    $qU = mysqli_query($con, "UPDATE end_marks SET mark='".$mark."', comment='".$comment."' WHERE student_id='".$id."' and term='".$term."' and form='".$form."' and subject='".$subject."'");
                } else {
                    $q = mysqli_query($con, "INSERT into end_marks (student_id, teacher_id, sname, ssurname, tsurname, class, form, term, year, subject, mark, comment) values ('".$id."', '".$row1['id']."', '".$name."', '".$surname."', '".$row1['surname']."', '".$class."', '".$form."', '".$term."', '".$year."','".$subject."', '".$mark."', '".$comment."')");
                }
                
        }

            

            
            
        }

        $publish = mysqli_query($con, "select * from publish where term='".$term."' and year='".$year."'");
        if (mysqli_num_rows($publish)==0) {
            $pub = mysqli_query($con, "INSERT into publish (term, year) values ('".$term."', '".$year."')");
        }
        
        header("Location:class.php?success=Added Results Successfully&form=$form&class=$class&subject=$subject&term=$term&year=$year");

        
    }
    else {
        $term = $_REQUEST['term'];
        $form = $_REQUEST['form'];
        $class = $_REQUEST['class'];
        $subject = $_REQUEST['subject'];
        $mark = $_REQUEST[$id.",".$subject."_mark"];
        $comment = $_REQUEST[$id.",".$subject."_comment"];

        header("Location:class.php?error=Failed to add Results&form=$form&class=$class&subject=$subject&term=$term&year=$year");
    }

    
   
   
}

?>