<?php
session_start();
include '../../../../database/connect.php' ;
if(isset($_SESSION['user_data'])){
    if(!isset($_REQUEST['student_id'])){
        header("Location:../studentsTest.php?error=Please Enter Id");
    }
    $q = mysqli_query($con, "SELECT * FROM users WHERE id='".$_REQUEST['student_id']."'");
    $row = mysqli_fetch_assoc($q);
    if(mysqli_num_rows($q)==0){
        header("Location:../studentsTest.php?error=Student Id Not Found");
    }

    $q1 = mysqli_query($con, "SELECT * FROM users WHERE id='".$_REQUEST['teacher_id']."'");
    $row1 = mysqli_fetch_assoc($q1);

    $data4 = array();
    $q4 = mysqli_query($con, "SELECT * from subs where user_id='".$_SESSION['user_data']['id']."' ORDER BY subject ASC");
    while($row4=mysqli_fetch_assoc($q4)){
        array_push($data4,$row4);
    }

    $year=date("Y");
    $term = $_REQUEST['term'];

    if(count($_POST)>0) {

        foreach ($data4 as $d4){
            $q = mysqli_query($con, "INSERT into end_marks (student_id, teacher_id, sname, ssurname, tsurname, class, form, term, year, subject, mark, comment) values ('".$row['id']."', '".$row1['id']."', '".$row['name']."', '".$row['surname']."', '".$row1['surname']."', '".$row['class']."', '".$row['form']."', '".$term."', '".$year."','".$d4['subject']."', '".$_REQUEST[$d4['subject'].'_mark']."', '".$_REQUEST[$d4['subject'].'_comment']."')");
        }
        
        $id = $_REQUEST['student_id'];
        $term = $_REQUEST['term'];
        $form = $_REQUEST['form'];
        $class = $_REQUEST['class'];
        header("Location:../class.php?success=Added Results Successfully&form=$form&class=$class");

        
    }
    else {
        $id = $_REQUEST['student_id'];
        $term = $_REQUEST['term'];
        $form = $_REQUEST['form'];
        $class = $_REQUEST['class'];
        header("Location:../class.php?error=Failed to add Results&form=$form&class=$class");
    }

    $publish = mysqli_query($con, "select * from publish where term='".$term."' and year='".$year."'");
    if (mysqli_num_rows($publish)==0) {
        $pub = mysqli_query($con, "INSERT into publish (term, year) values ('".$term."', '".$year."')");
    }
   
   
}

?>