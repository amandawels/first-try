<?php include "../../path.php";
session_start();
include '../../../../database/connect.php' ;
if(isset($_SESSION['user_data'])){
    if($_SESSION['user_data']['rank']!=2){
        if($_SESSION['user_data']['rank']!=3){
            if($_SESSION['user_data']['rank']!=5){
                session_destroy();
                header("Location:../../logout.php");
            }
        }
        
    }

    $form = $_REQUEST['form'];
    $class = $_REQUEST['class'];

    $q = mysqli_query($con, "SELECT * FROM term WHERE id='1'");
    $row=mysqli_fetch_assoc($q);

    
    $data = array();
    $q1 = mysqli_query($con, "SELECT * from subs WHERE form='".$form."' AND class='".$class."' ORDER BY subject ASC");
    while($row1=mysqli_fetch_assoc($q1)){
        array_push($data,$row1);
    }

    $data2 = array();
    $q2 = mysqli_query($con, "SELECT id, name, surname FROM users WHERE form='".$_REQUEST['form']."'  AND class='".$_REQUEST['class']."' ORDER BY surname ASC");
    while($row2=mysqli_fetch_assoc($q2)){
        array_push($data2,$row2);
    }
    

?>




<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $rowS['short_name'] ?> Staff</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/iconfonts/font-awesome/css/all.min.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../../../settings/<?php echo $rowS['favicon'] ?>" />
  <style>
      @media only print {
         body {
            visibility: hidden;
         }
         .cssInp {
            visibility: visible;
         }
         @page {size: landscape};
      }
   </style>
</head>
<body>
  <div class="">
    <!-- partial:partials/_navbar.html -->
      <!-- partial -->
      <div class="cssInp">

            <div class="content-wrapper">
                <div class="page-header">
                    <h3 class="page-title">
                    Mark Schedule, Form <?php echo ($_REQUEST['form'].", ".$_REQUEST['class']); ?>
                    
                    </h3>
                    <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="../class.php?form=<?php echo $form ?>&class=<?php echo $class ?>">Class</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Mark Order</li>
                    </ol>
                    </nav>
                </div>
                <div class="row">
                    <div class="col-12 grid-margin">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">(Test <?php echo $_REQUEST['test_number'] ?> Results)</h4>
                            
                            <div class="row">
                                <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th class="sortStyle">Student Name</th>
                                        <?php foreach($data as $d) : ?>
                                        <th class="sortStyle"><?php echo $d['abb'] ?></th>
                                        <?php endforeach; ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($data2 as $key=>$d2) : ?>
                                        <tr>
                                            <td><?php echo $d2['surname']." ".$d2['name'] ?></td>
                                            <?php foreach($data as $d) : ?>
                                                <?php 
                                                    $q = mysqli_query($con, "select subject, mark from end_test where student_id='".$d2['id']."' AND form='".$_REQUEST['form']."' AND class='".$_REQUEST['class']."' AND subject='".$d['subject']."' AND test_number='".$_REQUEST['test_number']."'");
                                                    $row=mysqli_fetch_assoc($q);         
                                                ?>
                                                <?php if(isset($q)) { ?>
                                                    <?php $mark=$row['mark']; if ($mark>50){ ?>
                                                        <td><b><span style="color: green;"><?php echo $mark; ?></span></b></td>
                                                    <?php } else { ?>
                                                        <td><b><span style="color: red;"><?php echo $mark; ?></span></b></td>
                                                    <?php } ?>
                                                <?php } else { ?>
                                                    <td></td>
                                                <?php } ?>

                                            <?php endforeach; ?>
                                            
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table><br>
                                
                                <div id="cssBtnWrap">

                                    <div class="form-group">
                                        <a href="../class.php?form=<?php echo $form ?>&class=<?php echo $class ?>" class="btn btn-primary"><i class="fa fa-home menu-icon"></i> Go to Class</a>
                                        <button onclick="cssPrint()" class="btn btn-success"><i class="fa fa-print menu-icon"></i> Print</button>
                                    </div>
                                    
                                </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <p id="cssOp"></p>
                </div>
            </div>

            <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php $year=date("Y"); echo $year; ?>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="far fa-heart text-danger"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script>
      var cssOutEl = document.getElementById("cssOp");
      var cssBtnWrapEl = document.getElementById("cssBtnWrap");
      function cssPrint() {
         cssOutEl.innerHTML = "Printing the document...";
         cssBtnWrapEl.style.display = "none";
         print();
      }
   </script>
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <script src="../../vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/misc.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>

  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="../../js/file-upload.js"></script>
  <script src="../../js/typeahead.js"></script>
  <script src="../../js/select2.js"></script>
  <!-- End custom js for this page-->
</body>
<?php } else { 
        session_destroy();
        header("Location:../../index.php");
    } ?>

<!-- Mirrored from www.urbanui.com/melody/template/pages/forms/basic_elements.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Sep 2018 06:07:34 GMT -->
</html>