<?php
session_start();
include '../../database/connect.php' ;

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);

$q = mysqli_query($con, "select * from users where id='".$_SESSION['user_data']['id']."'");
$row=mysqli_fetch_assoc($q);

$id = $row['id'];
$password=mysqli_real_escape_string($con,$_REQUEST['password']);
$confirm_password=mysqli_real_escape_string($con,$_REQUEST['confirm_password']);

//Validate user input
if(empty($password) || empty($confirm_password)) {
    header("Location:setPassword.php?error=Both fields are required");
} elseif($password !== $confirm_password){
    header("Location:setPassword.php?error=Passwords do not match");
} elseif(!preg_match('/^[a-zA-Z0-9]*[^\w\s]+[a-zA-Z0-9]*$/', $password)) {
    //Validate password
    header("Location:setPassword.php?error=Password must contain at least one special character");
} elseif(strlen($password) < 8) {
    header("Location:setPassword.php?error=Password must contain at least 8 characters");
} else {
    //generate random salt
    //$salt = mt_rand();

    //Hash password with salt using MD5 algorithm
    $hashed_password = md5($password);

    //store details in database
    $q = mysqli_query($con, "UPDATE users SET password='".$hashed_password."' WHERE id='".$id."'");
    if ($q) {
        header("Location:../index.php?success=Set New Secure Password Successfully");
    }
    else {
        header("Location:../index.php?error=Failed to Set New Secure Password. Try Again");
    }
}

?>