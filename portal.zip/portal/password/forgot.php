<?php
session_start();
include '../../database/connect.php' ;

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);
// $username = $_REQUEST['username'];

if(count($_POST)>0) {
    $username = strtolower($_REQUEST['username']);

    $q = mysqli_query($con, "select * from users where username='".$username."'");
    if (mysqli_num_rows($q)>0) {
        $data = mysqli_fetch_assoc($q);
        $_SESSION['user_data']=$data;

        // header("Location:forgot.php?username=$username"); 
    }
}

if(isset($_SESSION['user_data'])){

    $q1 = mysqli_query($con, "select * from users where id='".$_SESSION['user_data']['id']."'");
    $row=mysqli_fetch_assoc($q1);

    $dataQuestion = array();
    $qQuestion = mysqli_query($con, "SELECT * FROM security WHERE student_id='".$row['id']."' ORDER BY id ASC");
    while($rowQuestion=mysqli_fetch_assoc($qQuestion)){
        array_push($dataQuestion,$rowQuestion);
    }


?>

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.urbanui.com/melody/template/pages/samples/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Sep 2018 06:08:53 GMT -->
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $rowS['short_name'] ?> -- Set Password</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/font-awesome/css/all.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../settings/<?php echo $rowS['favicon'] ?>" />
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth">
        <div class="row w-100">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left p-5">
                <center>
                
                    <h5>Enter The Correct Answers</h5>

                    <div class="row">
                        <?php if(isset($_REQUEST['success'])) { ?>
                            <div class="col-lg-12">
                                <span class="alert alert-success alert-block" style="display: block;"><?php echo $_REQUEST['success']; ?></span>
                            </div>
                        <?php } ?>
                    </div>  
                    <div class="row">
                        <?php if(isset($_REQUEST['error'])) { ?>
                            <div class="col-lg-12">
                                <span class="alert alert-danger alert-block" style="display: block;"><?php echo $_REQUEST['error']; ?></span>
                            </div>
                        <?php } ?>
                    </div>
                    
                </center>
              
              

              <form class="pt-3" method="POST" action="forgot2.php">
                <?php foreach ($dataQuestion as $dQuestion) { ?>
                <div class="form-group row">
                    <input type="text" name="question_<?php echo $dQuestion['id'] ?>" class="form-control form-control-lg" id="id" value="<?php echo $dQuestion['security_question'] ?>" required>
                    <input type="text" name="answer_<?php echo $dQuestion['id'] ?>" class="form-control form-control-lg" id="id" placeholder="Enter Your Answer" required>
                </div>
                <?php } ?>

                <div class="mt-3">
                    <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">Proceed</button>
                </div>
              </form>

                <!-- <div class="my-2 d-flex justify-content-between align-items-center">
                  <div class="form-check">
                    <label class="form-check-label text-muted">
                      <input type="checkbox" class="form-check-input">
                      Keep me signed in
                    </label>
                  </div>
                  <a href="#" class="auth-link text-black">Forgot password?</a>
                </div>
                <div class="mb-2">
                  <button type="button" class="btn btn-block btn-facebook auth-form-btn">
                    <i class="fab fa-facebook-f mr-2"></i>Connect using facebook
                  </button>
                </div>
                <div class="text-center mt-4 font-weight-light">
                  Don't have an account? <a href="register.html" class="text-primary">Create</a>
                </div> -->


              
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
</body>

<?php } else { 
        session_destroy();
        header("Location:../index.php");
} ?>

<!-- Mirrored from www.urbanui.com/melody/template/pages/samples/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Sep 2018 06:08:53 GMT -->
</html>
