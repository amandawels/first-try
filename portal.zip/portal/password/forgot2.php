<?php
session_start();
include '../../database/connect.php' ;

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);

$q = mysqli_query($con, "select * from users where id='".$_SESSION['user_data']['id']."'");
$row=mysqli_fetch_assoc($q);

$dataQuestion = array();
$qQuestion = mysqli_query($con, "SELECT * FROM security WHERE student_id='".$row['id']."' ORDER BY id ASC");
while($rowQuestion=mysqli_fetch_assoc($qQuestion)){
    array_push($dataQuestion,$rowQuestion);
}
$up = mysqli_query($con, "UPDATE security SET checkQ=0");

foreach ($dataQuestion as $dQuestion) {
    $id = $dQuestion['id'];
    $answer = $_REQUEST['answer_'.$dQuestion['id']];
    $question = $_REQUEST['question_'.$dQuestion['id']];

    if (isset($answer) && isset($question)){
        $q2 = mysqli_query($con, "SELECT * FROM security WHERE security_question='".$question."' AND answer='".$answer."'");
        $row2=mysqli_fetch_assoc($q2);

        if (mysqli_num_rows($q2)>0) {
            $v = mysqli_query($con, "UPDATE security SET checkQ=1 WHERE security_question='".$question."' AND answer='".$answer."'");
        } else {
            // echo "The question '".$question."' is wrong.";
            header("Location:forgot.php?error=The answer to the question '$question' is wrong."); 
            break;
        }
    } else {
        // echo "The question '".$question."' is wrong.";
        header("Location:forgot.php?error=The answer to the question '$question' is wrong.");
        break;
    }

}

$dataQuestion2 = array();
$qQuestion2 = mysqli_query($con, "SELECT * FROM security WHERE student_id='".$row['id']."' ORDER BY id ASC");
while($rowQuestion2=mysqli_fetch_assoc($qQuestion2)){
    array_push($dataQuestion2,$rowQuestion2);
}

foreach ($dataQuestion2 as $dQuestion2) {
    $check = $dQuestion2['checkQ'];
    if ($check==0){
        header("Location:forgot.php?error=The answer to the question '$question' is wrong.");
        break;
    } else {
        // echo "Success. Check: ".$check;
        $up = mysqli_query($con, "UPDATE security SET checkQ=0");
        header("Location:setPassword.php?success=Successfully confirmed security questions. You can now change your password.");
    }
}

// header("Location:setPassword.php?success=Successfully confirmed security questions. You can now change your password.");


?>