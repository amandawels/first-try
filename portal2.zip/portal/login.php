<?php
session_start();
include '../database/connect.php' ;
if (isset($_REQUEST['username']) && isset($_REQUEST['password'])){

    $school = mysqli_real_escape_string($con, $_REQUEST['school']);

    $username1 = mysqli_real_escape_string($con, $_REQUEST['username']);
    $username = strtolower($username1);
    $pass = mysqli_real_escape_string($con, $_REQUEST['password']);
    $password = md5($pass); 

    $q = mysqli_query($con, "SELECT * FROM users WHERE username='".$username."' AND school='".$school."'");

    if (mysqli_num_rows($q)>0) {
        $data = mysqli_fetch_assoc($q);
        $_SESSION['user_data']=$data;

        $qSQ = mysqli_query($con, "SELECT * FROM security WHERE student_id='".$_SESSION['user_data']['id']."' AND school='".$school."'");
        $rowSQ=mysqli_fetch_assoc($qSQ);

        if (isset($data['password']) && $password==$data['password'] && isset($rowSQ['answer'])){
            if($data['rank']==1){
                header("Location:admin/home.php");
            } elseif ($data['rank']==2) {
                header("Location:staff/home.php");
            } elseif ($data['rank']==3) {
                header("Location:staff/home.php");
            } elseif ($data['rank']==4) {
                header("Location:admin/home.php");
            } elseif ($data['rank']==5) {
                header("Location:staff/home.php");
            } elseif ($data['rank']==6) {
                header("Location:../index.php?error=Your portal has not been created yet");
            } elseif ($data['rank']==7) {
                header("Location:student/home.php");
            } else {
                header("Location:student/locked.php");
            }
        } else if ($data['password']=='blank'){
            header("Location:password/setPassword.php"); 
        } else if ($data['password']!='blank' && !isset($rowSQ['answer'])){
            header("Location:password/setSecurityQuestion.php"); 
        } else {
            header("Location:index.php?error=Error encountered, please try again. If error persists contact the admin."); 
        }

        
    }
    else {
        header("Location:index.php?error=User Does Not Exist"); 
    }
}
else {
    header("Location:index.php?error=User Doesn't Exist");
}
?>