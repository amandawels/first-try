<?php
session_start();
include '../../../../database/connect.php' ;

if(isset($_SESSION['user_data'])){

    if(!isset($_REQUEST['student_id'])){
        header("Location:../studentsTest.php?error=Please Enter Id");
    }

    $data4 = array();
    $q4 = mysqli_query($con, "SELECT * from subs where user_id='".$_SESSION['user_data']['id']."' ORDER BY subject ASC");
    while($row4=mysqli_fetch_assoc($q4)){
        array_push($data4,$row4);
    }
    $q = mysqli_query($con, "SELECT * FROM users WHERE id='".$_REQUEST['student_id']."'");
    $row = mysqli_fetch_assoc($q);

    if(count($_POST)>0) {

        foreach ($data4 as $d4){
            mysqli_query($con, "UPDATE end_test SET mark='".$_REQUEST[$d4['subject'].'_mark']."' WHERE student_id='".$_REQUEST['student_id']."' and test_number='".$_REQUEST['test_number']."' and term = '".$_REQUEST['term']."' and subject='".$d4['subject']."'");
        }
    
        $id = $_REQUEST['student_id'];
        $term = $_REQUEST['term'];
        $test_number = $_REQUEST['test_number'];
        $form = $_REQUEST['form'];
        $class = $row['class'];
        header("Location:../class.php?success=Added Results Successfully&form=$form&class=$class");
    }
}
?>