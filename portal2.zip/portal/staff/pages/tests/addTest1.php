<?php
session_start();
include '../../../../database/connect.php' ;
if(isset($_SESSION['user_data'])){
    if(!isset($_REQUEST['student_id'])){
        header("Location:../studentsTest.php?error=Please Enter Id");
    }
    $q = mysqli_query($con, "SELECT * FROM users WHERE id='".$_REQUEST['student_id']."'");
    $row = mysqli_fetch_assoc($q);
    if(mysqli_num_rows($q)==0){
        header("Location:../studentsTest.php?error=Student Id Not Found");
    }

    $q1 = mysqli_query($con, "SELECT * FROM users WHERE id='".$_REQUEST['teacher_id']."'");
    $row1 = mysqli_fetch_assoc($q1);

    $data4 = array();
    $q4 = mysqli_query($con, "SELECT * from subs where user_id='".$_SESSION['user_data']['id']."' ORDER BY subject ASC");
    while($row4=mysqli_fetch_assoc($q4)){
        array_push($data4,$row4);
    }

    if(count($_POST)>0) {

        foreach ($data4 as $d4){

            $q = mysqli_query($con, "INSERT into end_test (student_id, name, surname, test_number, class, form, term, subject, mark) values ('".$row['id']."','".$row['name']."','".$row['surname']."', '".$_REQUEST['test_number']."', '".$row['class']."', '".$row['form']."', '".$_REQUEST['term']."','".$d4['subject']."', '".$_REQUEST[$d4['subject'].'_mark']."')");
        }

        $id = $_REQUEST['student_id'];
        $term = $_REQUEST['term'];
        $test_number = $_REQUEST['test_number'];
        $form = $row['form'];
        $class = $row['class'];
        header("Location:../class.php?success=Added Results Successfully&form=$form&class=$class");

        $q3 = mysqli_query($con, "UPDATE users SET term='".$_REQUEST['term']."' WHERE rank>6");
    }

    else {
        $id = $_REQUEST['student_id'];
        $term = $_REQUEST['term'];
        $test_number = $_REQUEST['test_number'];
        $form = $row['form'];
        $class = $row['class'];
        header("Location:../class.php?error=Failed to add Results&form=$form&class=$class");
    }
   
   
}

?>