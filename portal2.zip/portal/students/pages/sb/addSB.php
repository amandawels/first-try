<?php
include '../../../../database/connect.php' ;
session_start();
if(isset($_SESSION['user_data'])){
    header("Location:sb.php");
}
$title=mysqli_real_escape_string($con,$_REQUEST['title']);
$content=mysqli_real_escape_string($con,$_REQUEST['content']);

$q = mysqli_query($con, "INSERT into sb (title, content, name, surname) values ('".$title."','".$content."','".$_SESSION['user_data']['name']."','".$_SESSION['user_data']['surname']."')");
if ($q) {
    header("Location:sb.php?success=Suggestion Sent Successfully");
}
else {
    header("Location:sb.php?error=Failed to send Suggestion");
}
?>