<?php include "../../path.php";
session_start();
if(isset($_SESSION['user_data'])){
  if($_SESSION['user_data']['rank']!=7){
      session_destroy();
      header("Location:../../logout.php");
      
  }

    include '../../../../database/connect.php' ;
    $q = mysqli_query($con, "select * from users where id='".$_SESSION['user_data']['id']."'");
    $row=mysqli_fetch_assoc($q);

    $data1 = array();
    $q1 = mysqli_query($con, "SELECT * FROM arrears WHERE student_id='".$_SESSION['user_data']['id']."' ORDER BY id DESC LIMIT 2");
    while($row1=mysqli_fetch_assoc($q1)){
        array_push($data1,$row1);
    }

    $data2 = array();
    $q2 = mysqli_query($con, "SELECT * FROM fees_record WHERE student_id='".$_SESSION['user_data']['id']."' ORDER BY id DESC LIMIT 2");
    while($row2=mysqli_fetch_assoc($q2)){
        array_push($data2,$row2);
    }

    // $update1 = mysqli_query($con, "SELECT * FROM arrears WHERE student_id='".$_SESSION['user_data']['id']."' ORDER BY id DESC LIMIT 1");
    // $row1 = mysqli_fetch_array($update1);

    // $update2 = mysqli_query($con, "SELECT * FROM fees_record WHERE student_id='".$_SESSION['user_data']['id']."' ORDER BY id DESC LIMIT 1");
    // $row2 = mysqli_fetch_array($update2);

    $today_date = date("Y-m-d");

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);

    $dataCalendar = array();
    $qCalendar = mysqli_query($con, "SELECT * FROM calendar WHERE '".$today_date."' <= date ORDER BY date ASC LIMIT 5");
    while($rowCalendar=mysqli_fetch_assoc($qCalendar)){
        array_push($dataCalendar,$rowCalendar);
    }

    $dataN = array();
    $qN = mysqli_query($con, "SELECT * FROM notices ORDER BY date ASC LIMIT 5");
    while($rowN=mysqli_fetch_assoc($qN)){
        array_push($dataN,$rowN);
     }

    


    
?>
<!DOCTYPE html>
<html lang="en">


<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $rowS['short_name'] ?> Student</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/iconfonts/font-awesome/css/all.min.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../../../settings/<?php echo $rowS['favicon'] ?>" />
</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    
        <!-- Open Header -->

        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row default-layout-navbar">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                <a class="navbar-brand brand-logo" href="../../home.php"><img src="../../../../settings/<?php echo $rowS['logo_main'] ?>" alt="logo"/></a>
        <a class="navbar-brand brand-logo-mini" href="../../home.php"><img src="../../../../settings/<?php echo $rowS['logo_small'] ?>" alt="logo"/></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-stretch">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="fas fa-bars"></span>
        </button>
        
        <ul class="navbar-nav navbar-nav-right">
          
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              <img src="<?php echo "../../images/comment.jpg" ?>" alt="profile"/>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <a class="dropdown-item" href="<?php echo "../profile/profile.php"; ?>">
                <i class="fas fa-cog text-primary"></i>
                Settings
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="<?php echo "../../logout.php"; ?>">
                <i class="fas fa-power-off text-primary"></i>
                Logout
              </a>
            </div>
          </li>
          <li class="nav-item nav-settings d-none d-lg-block">
            <a class="nav-link" href="#">
              <i class="fas fa-ellipsis-h"></i>
            </a>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="fas fa-bars"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      
      <div id="right-sidebar" class="settings-panel">
        <i class="settings-close fa fa-times"></i>
        <ul class="nav nav-tabs" id="setting-panel" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="todo-tab" data-toggle="tab" href="#todo-section" role="tab" aria-controls="todo-section" aria-expanded="true">UPCOMING EVENTS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="chats-tab" data-toggle="tab" href="#chats-section" role="tab" aria-controls="chats-section">NOTICES</a>
          </li>
        </ul>

        <div class="tab-content" id="setting-content">
          <div class="tab-pane fade show active scroll-wrapper" id="todo-section" role="tabpanel" aria-labelledby="todo-section">
            <div class="add-items d-flex px-3 mb-0">
              <!-- <form class="form w-100">
                <div class="form-group d-flex">
                  <input type="text" class="form-control todo-list-input" placeholder="Add To-do">
                  <button type="submit" class="add btn btn-primary todo-list-add-btn" id="add-task-todo">Add</button>
                </div>
              </form> -->
            </div>
            
            <?php foreach ($dataCalendar as $dCalendar): ?>
            <div class="events py-4 border-bottom px-3">
              <div class="wrapper d-flex mb-2">
                <div class="tg-widgetcontent">
                  <div class="item">
                    <div id="tg-comments" class="tg-comments">
                        <div class="tg-comment">
                          <figure><a href="#"></a></figure>
                          <div class="tg-commentcontent">
                            <div class="">
                              <span><i class="fas fa-calendar"></i> <?php $date = $dCalendar['date']; echo date("F d, Y", strtotime($date)); ?></span>
                              <h5><?php echo $dCalendar['title'] ?></h5>
                            </div>
                          </div>
                        </div>		
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; ?>

          </div>

          <!-- To do section tab ends -->
          <div class="tab-pane fade" id="chats-section" role="tabpanel" aria-labelledby="chats-section">

            <ul class="chat-list">
            <?php foreach ($dataN as $dNotice): ?>
              <li class="list active">
                <div class="profile"><i class="fas fa-calendar"></i></div>
                <div class="info">
                  <p><?php echo $dNotice['title'] ?></p>
                </div>
              </li><br>
              <?php endforeach; ?>
              
            </ul>
          </div>
          <!-- chat tab ends -->
        </div>
      </div>
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">

          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="profile-image">
                <img src="<?php echo "../../images/comment.jpg" ?>" alt="image"/>
              </div>
              <div class="profile-name">
                <p class="name">
                <?php echo($_SESSION['user_data']['name']." ".$_SESSION['user_data']['surname']); ?>
                </p>
                <p class="designation">
                  Student
                </p>
              </div>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?php echo "home.php"; ?>">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          
          
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#results" aria-expanded="false" aria-controls="results">
              <i class="fa fa-book menu-icon"></i>
              <span class="menu-title">Results</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="results">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="<?php echo "../test/selectTest.php"; ?>">Continuous Assessment</a></li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo "../end/selectClass.php"; ?>">End of Term Results</a></li>
              </ul>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?php echo "../finances/finance.php"; ?>">
              <i class="fa fa-credit-card menu-icon"></i>
              <span class="menu-title">Financials</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo "../sb/sb.php"; ?>">
              <i class="fa fa-envelope menu-icon"></i>
              <span class="menu-title">Suggestion Box</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?php echo "../profile/profile.php"; ?>">
              <i class="fa fa-cog menu-icon"></i>
              <span class="menu-title">Settings</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?php echo "../../logout.php"; ?>">
              <i class="fa fa-power-off menu-icon"></i>
              <span class="menu-title">Logout</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?php echo "../../../../index.php"; ?>">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Go to Public</span>
            </a>
          </li>

          <br><br>

          
        </ul>
      </nav>

      <!-- Close Header -->
    
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
            <h3 class="page-title">
              Finances
            </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="../../home.php">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Finances</li>
                </ol>
            </nav>
          </div>
          
          
          
          
          
          <div class="row">
            <div class="col-sm-1"></div>
                <div class="col-sm-10">
                    <?php
                      $is_cleared = false;
                      if(($row['arrears'])>0){
                          $is_cleared = true;
                      } 
                    ?>
                    <?php if(($is_cleared)==false) { ?>
                    <a href=""><div class="card bg-danger mb-4 text-light"></a>
                    <div class="card-body text-center"><strong><h2>Finances</h2></strong></div>
                    <div class="card-body align-items-center text-center">

                      <table class="table">
                          <tr>
                              <th><h3>Debit</h3></th>
                              <th><h3>Credit</h3></th>
                          </tr>
                          <tr>
                              <td><h4><?php echo "Balance B/F: $".$row['bbf']; ?></h4></td>
                              <td><h4><?php echo "Paid Fees: $".$row['paid']; ?></h4></td>
                          </tr>
                          <tr>
                              <td><h4><?php echo "Total Fees: $".$row['total']; ?></h4></td>
                              <td><h4><?php // echo "Arrears: $".$row['arrears']; ?></h4></td>
                          </tr>
                      </table>

                      <!-- <label for="bbf"><strong>Balance B/F</strong></label><br>
                      <h2><?php // echo "$".$row['bbf']; ?></h2><br><hr> -->

                      <label for="arrears"><strong>Current Fees Balance</strong></label><br>
                      <h2><?php echo "$".$row['arrears']; ?></h2><br><hr>
                      
                    </div>  
                    <?php } else { ?>  
                      <a href=""><div class="card bg-success mb-4 text-light"></a>
                      <div class="card-body text-center"><strong><h2>Finances</h2></strong></div>
                    <div class="card-body align-items-center text-center">

                      <table class="table">
                          <tr>
                              <th><h3>Debit</h3></th>
                              <th><h3>Credit</h3></th>
                          </tr>
                          <tr>
                              <td><h4><?php echo "Balance B/F: $".$row['bbf']; ?></h4></td>
                              <td><h4><?php echo "Paid Fees: $".$row['paid']; ?></h4></td>
                          </tr>
                          <tr>
                              <td><h4><?php echo "Total Fees: $".$row['total']; ?></h4></td>
                              <td><h4><?php // echo "Arrears: $".$row['arrears']; ?></h4></td>
                          </tr>
                      </table>

                      <!-- <label for="bbf"><strong>Balance B/F</strong></label><br>
                      <h2><?php // echo "$".$row['bbf']; ?></h2><br><hr> -->

                      <label for="arrears"><strong>Current Fees Balance</strong></label><br>
                      <h2><?php echo "$".$row['arrears']; ?></h2><br><hr>
                      
                    </div> 
                    <?php } ?>             
                </div>
            </div>
            <div class="col-sm-1"></div>    
        </div>

        <div class="card">
            <div class="card-header">
                <h4>Fees Records</h4>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Receipt Number</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($data2 as $d2) { ?>
                        <tr>
                            <td><?php echo($d2['date']); ?></td>
                            <td>$<?php echo $d2['amount']; ?></td>
                            <td><?php echo $d2['id']; ?></td>
                        </tr>
                        <?php } ?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer">
            <center><a href="fees-records.php" class="btn btn-outline-primary">More Records</a></center>
            </div>



        </div><br>

        <div class="card">
            <div class="card-header">
                <h4>Fees Statement</h4>
            </div>
            
            <div class="card-footer">
            <center><a href="select_statement.php" class="btn btn-success">View Fees Statement</a></center>
            </div>



        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php $year=date("Y"); echo $year; ?>. All rights reserved.</span>

          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <script src="../../vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/misc.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="../../js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>
<?php } else { 
        session_destroy();
        header("Location:../../index.php");
    } ?>

</html>
