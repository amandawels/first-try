<?php
include 'header.php' ;
if (isset($_REQUEST['username']) && isset($_REQUEST['password'])){
    $username = mysqli_real_escape_string($con, $_REQUEST['username']);
    $password = mysqli_real_escape_string($con, $_REQUEST['password']);
    $q = mysqli_query($con, "select * from users where username='".$username."' and password='".$password."'");

    if (mysqli_num_rows($q)>0) {
        $data = mysqli_fetch_assoc($q);
        $_SESSION['user_data']=$data;
        if($data['rank']==1){
            header("Location:../admin/home.php");
        } elseif ($data['rank']==2) {
            header("Location:../staff/home.php");
        } elseif ($data['rank']==3) {
            header("Location:../staff/home.php");
        } elseif ($data['rank']==4) {
            header("Location:../admin/home.php");
        } elseif ($data['rank']==5) {
            header("Location:../staff/home.php");
        } elseif ($data['rank']==6) {
            header("Location:../../index.php?error=Your portal has not been created yet");
        } elseif ($data['rank']==7) {
            header("Location:home.php");
        } else {
            header("Location:locked.php");
        }
    }
    else {
        header("Location:index.php?error=Please Enter Correct Credentials"); 
    }
}
else {
    header("Location:index.php?error=Please Enter Your Credentials");
}
?>