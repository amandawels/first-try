<?php
include 'header.php';

$data = array();
$q = mysqli_query($con, "SELECT * FROM publish WHERE school='".$school."' ORDER BY id DESC");
while($row=mysqli_fetch_assoc($q)){
    array_push($data,$row);
}

?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.urbanui.com/melody/template/pages/tables/data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Sep 2018 06:08:40 GMT -->
<?php include "nav.php" ?>

      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
            <div class="page-header">
                <h3 class="page-title">
                Publish Results
                </h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="home.php">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Publish Results</li>
                    </ol>
                </nav>
            </div>

            <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-12">
                  <div class="row">
                      <?php if(isset($_REQUEST['success'])) { ?>
                          <div class="col-lg-12">
                              <span class="alert alert-success alert-block" style="display: block;"><?php echo $_REQUEST['success']; ?></span>
                          </div>
                      <?php } ?>
                  </div>  
                  <div class="row">
                      <?php if(isset($_REQUEST['error'])) { ?>
                          <div class="col-lg-12">
                              <span class="alert alert-danger alert-block" style="display: block;"><?php echo $_REQUEST['error']; ?></span>
                          </div>
                      <?php } ?>
                  </div>
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Term</th>
                                <th>Year</th>
                                <th>Publish</th>
                                <th>Statistics</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                foreach($data as $key=>$d3) {
                            ?>
                            <tr>
                                <td><?php echo $key+1 ?></td>
                                <td><?php echo $d3['term']; ?></td>
                                <td><?php echo $d3['year']; ?></td>
                                <td>
                                <?php
                                    $is_published = false;
                                    if(($d3['published'])==1){
                                        $is_published = true;
                                    } 
                                    ?>
                                    <?php if(($is_published)==false) { ?>
                                        <a href="publish1.php?id=<?php echo $d3['id']; ?>" class="btn btn-success">Publish Results</a>
                                    <?php } else { ?>
                                        <a href="unpublish1.php?id=<?php echo $d3['id']; ?>" class="btn btn-danger">UnPublish</a>
                                <?php } ?>
                                </td>
                                <td>
                                    <?php
                                        $is_generated = false;
                                        if(($d3['published'])==1 and ($d3['generate'])==0){
                                            $is_generated = true;
                                        } 
                                    ?>
                                    <?php if(($is_generated)==true) { ?>
                                        <a href="stats.php?id=<?php echo $d3['id']; ?>&term=<?php echo $d3['term']; ?>&year=<?php echo $d3['year'] ?>" class="btn btn-warning"> Generate Statistics</a>
                                    <?php } else { echo "Statistics Generated"; } ?>
                                </td>
                            </tr>
                            <?php } ?>
                            
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php $year=date("Y"); echo $year; ?>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="far fa-heart text-danger"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/data-table.js"></script>
  <!-- End custom js for this page-->
</body>
<?php } else { 
        session_destroy();
        header("Location:HOME");
    } ?>

<!-- Mirrored from www.urbanui.com/melody/template/pages/tables/data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Sep 2018 06:08:41 GMT -->
</html>
