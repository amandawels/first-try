<?php
session_start();
include '../../../../database/connect.php';
$name=mysqli_real_escape_string($con,$_REQUEST['name']);
$nameu=strtr($name, array(' '=>''));
$surname=mysqli_real_escape_string($con,$_REQUEST['surname']);
$surnameu=strtr($surname, array(' '=>''));
$username=strtolower($nameu.$surnameu);
$password='blank';
$rank=mysqli_real_escape_string($con,$_REQUEST['rank']);
$sex=mysqli_real_escape_string($con,$_REQUEST['sex']);
$title=mysqli_real_escape_string($con,$_REQUEST['title']);
$department=mysqli_real_escape_string($con,$_REQUEST['department']);
$club=mysqli_real_escape_string($con,$_REQUEST['club']);
$level=mysqli_real_escape_string($con,$_REQUEST['level']);
$role=mysqli_real_escape_string($con,$_REQUEST['role']);
$phone=mysqli_real_escape_string($con,$_REQUEST['phone']);
$email=mysqli_real_escape_string($con,$_REQUEST['email']);

$pic = time() . '_' . $_FILES['pic']['name'];
$destination = "../../../../images/users/staff/" . $pic;
$result = move_uploaded_file($_FILES['pic']['tmp_name'], $destination);

$q = mysqli_query($con, "INSERT into users (rank, name, surname, username, password, sex, title, department, club, level, role, phone, email, pic) values ('".$rank."','".$name."','".$surname."','".$username."','".$password."','".$sex."','".$title."','".$department."','".$club."','".$level."','".$role."','".$phone."','".$email."','".$pic."')");
if ($q) {
    header("Location:all-staff.php?success=Staff Added Successfully");
}
else {
    header("Location:all-staff.php?error=Failed to add Staff");
}
?>