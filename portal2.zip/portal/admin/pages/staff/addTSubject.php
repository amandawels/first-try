<?php
session_start();
include '../../../../database/connect.php';
$id=mysqli_real_escape_string($con,$_REQUEST['id']);
$subject=mysqli_real_escape_string($con,$_REQUEST['subject']);

$q = mysqli_query($con, "INSERT into subs (user_id, subject) values ('".$id."','".$subject."')");

if ($q) {
    header("Location:t_subs.php?id=$id&success=Added Successfully");
}
else {
    header("Location:t_subs.php?id=$id&error=Failed to add Subject");
}
?>