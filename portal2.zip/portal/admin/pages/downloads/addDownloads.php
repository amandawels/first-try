<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$title=mysqli_real_escape_string($con,$_REQUEST['title']);

$download = time() . '_' . $_FILES['download']['name'];
$destination = "../../../../downloads/" . $download;
$result = move_uploaded_file($_FILES['download']['tmp_name'], $destination);


$q = mysqli_query($con, "INSERT into downloads (title, download) values ('".$title."', '".$download."')");
if ($q) {
    header("Location:all-downloads.php?success=Uploaded File Successfully");
}
else {
    header("Location:all-downloads.php?error=Failed to add File");
}
?>