<?php
session_start();
include '../../../../database/connect.php';
if(count($_POST)>0) {
    $data = array();
    $update = mysqli_query($con, "SELECT * FROM users WHERE rank>6");
    while($row = mysqli_fetch_array($update)){
        array_push($data,$row);
    }

    foreach($data as $d) {

        $paid=0;
        
        $year=date("Y");
        $date=$year;
        $new = $paid-$d['total'];

        $bbf = $d['arrears'];
        $new_bbf = $bbf - $bbf - $bbf;

        mysqli_query($con, "INSERT INTO arrears (student_id, date, name, surname, term, form, amount, total) values ('".$d['id']."', '".$date."', '".$d['name']."', '".$d['surname']."', '".$d['term']."', '".$d['form']."', '".$d['arrears']."', '".$d['total']."')");
        mysqli_query($con, "UPDATE users SET paid=0, bbf='".$new_bbf."' WHERE id='".$d['id']."'" );
        mysqli_query($con, "UPDATE feesdata SET paid=0");
        
        // echo "Name: ".$d['name']." ".$d['surname']."; ";
        // echo "Balance B/F: ".$new_bbf."; ";
        // echo "Arrears: ".$d['arrears']."; ";
        // echo "Total: ".$d['total']."; ";
    }

    

    header("Location:all-students.php?success=Reset Students' Finances Successfully");

    
}
?>