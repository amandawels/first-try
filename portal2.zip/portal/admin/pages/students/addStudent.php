<?php
session_start();
include '../../../../database/connect.php';

$q = mysqli_query($con, "SELECT * FROM total WHERE id='1'");
$row = mysqli_fetch_assoc($q);

$name=mysqli_real_escape_string($con,$_REQUEST['name']);
$nameu=strtr($name, array(' '=>''));
$surname=mysqli_real_escape_string($con,$_REQUEST['surname']);
$surnameu=strtr($surname, array(' '=>''));
$username=strtolower($nameu.$surnameu);
$password='blank';
$sex=mysqli_real_escape_string($con,$_REQUEST['sex']);
$form=mysqli_real_escape_string($con,$_REQUEST['form']);
$term=mysqli_real_escape_string($con,$_REQUEST['term']);
$class=mysqli_real_escape_string($con,$_REQUEST['class']);
$intake=mysqli_real_escape_string($con,$_REQUEST['intake']);;


$total=0;
if (($form)<5){
    $total = $row['lower'];
} else if (($form)>4){
    $total = $row['upper'];
}


$q = mysqli_query($con, "INSERT into users (rank, name, surname, username, password, sex, form, class, total_school, term, intake) values ('7','".$name."','".$surname."','".$username."','".$password."','".$sex."','".$form."','".$class."','".$total."','".$term."','".$intake."')");

$updateTotal = mysqli_query($con, "SELECT * FROM total");
$rowTotal = mysqli_fetch_array($updateTotal); 

$c_science = $rowTotal['z_science'];

mysqli_query($con, "UPDATE users SET total_school='".$rowTotal['lower']."' WHERE form<5");
mysqli_query($con, "UPDATE users SET total_school='".$rowTotal['upper']."' WHERE form>4");

mysqli_query($con, "UPDATE users SET c_science='".$c_science."' WHERE science_number>0");

mysqli_query($con, "UPDATE users SET boarding='".$rowTotal['boarding']."' WHERE intake='boarder'");

$update1 = mysqli_query($con, "SELECT * FROM users WHERE id = (SELECT MAX(id) FROM users)");
$row1 = mysqli_fetch_array($update1);

$newID = $row1['id'];

if ($q) {
    header("Location:view-student.php?id=$newID");
}
else {
    header("Location:all-students.php?error=Failed to add Student");
}
?>