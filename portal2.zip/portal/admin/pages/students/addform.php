<?php

session_start();
include '../../../../database/connect.php' ;
$q_update=mysqli_query($con, "UPDATE users set form=form+1 where rank>6");
$form=mysqli_query($con, "UPDATE users set rank=9 where form=7");
$end=mysqli_query($con,  "DELETE FROM endmarks");
$test=mysqli_query($con,  "DELETE FROM testmarks");
header("Location:all-students.php?success=Updated Classes Successfully");


?>