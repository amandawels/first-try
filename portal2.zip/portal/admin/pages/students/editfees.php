<?php 
include "../../../../database/connect.php";
session_start(); 
if(isset($_SESSION['user_data'])){
    if($_SESSION['user_data']['rank']!=4){
        if($_SESSION['user_data']['rank']!=1){
            session_destroy();
            header("Location:../../logout.php");
        }
        
    }

    $today_date = date("Y-m-d");

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);

    $dataCalendar = array();
    $qCalendar = mysqli_query($con, "SELECT * FROM calendar WHERE '".$today_date."' <= date ORDER BY date ASC LIMIT 5");
    while($rowCalendar=mysqli_fetch_assoc($qCalendar)){
        array_push($dataCalendar,$rowCalendar);
    }

    $dataN = array();
    $qN = mysqli_query($con, "SELECT * FROM notices ORDER BY date ASC LIMIT 5");
    while($rowN=mysqli_fetch_assoc($qN)){
        array_push($dataN,$rowN);
     }

    

    if(!isset($_REQUEST['student_id'])){
        header("Location:all-students.php?error=Please Enter ID");
    }
    $qr = mysqli_query($con, "SELECT * FROM users WHERE id='".$_REQUEST['student_id']."'");
    if(mysqli_num_rows($qr)==0){
        header("Location:all-students.php?error=Student ID Not Found");
    }

    $f = mysqli_query($con, "SELECT * FROM users where id='".$_REQUEST['student_id']."'");
    $row=mysqli_fetch_assoc($f);

    $u = mysqli_query($con, "SELECT * FROM users where id='".$_SESSION['user_data']['id']."'");
    $row2=mysqli_fetch_assoc($u);

    $form = $row['form'];
    $term = $row['term'];
    $amount = $_REQUEST['amount'];
    $paid = $row['paid'];

    $year=date("Y");

    $new = $paid + $amount;
    $fees_record = mysqli_query($con, "INSERT INTO fees_record (student_id,amount,form,term, year) values ('".$_REQUEST['student_id']."','".$amount."','".$form."','".$term."','".$year."')");
    $q = mysqli_query($con, "UPDATE users SET paid='".$new."', amount='".$amount."' WHERE id='".$_REQUEST['student_id']."'");

    $id = $_REQUEST['student_id'];
    // header("Location:receipt.php?success=Edited Fees Successfully");
    if ($q) {
        header("Location:receipt.php?success=Updates Fees Successfully&id=$id");
    }
    else {
        header("Location:receipt.php?success=Updates Fees Successfully&id=$id");
    }

}
?>