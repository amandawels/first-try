<?php

session_start();
include '../../../../database/connect.php' ;
$id = $_REQUEST['id'];
$q_update=mysqli_query($con, "UPDATE users set rank=7 where id='".$_REQUEST['id']."'");

if (isset($id)){
    header("Location:view-student.php?success=Unlocked Account Successfully&id=$id");    
} else {
    header("Location:search.php?success=Unlocked Account Successfully");
}



?>