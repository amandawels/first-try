<?php
session_start();
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    if($_SESSION['user_data']['rank']!=4){
        if($_SESSION['user_data']['rank']!=1){
            session_destroy();
            header("Location:../../logout.php");
        }
        
    }

    $today_date = date("Y-m-d");

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);

    $dataCalendar = array();
    $qCalendar = mysqli_query($con, "SELECT * FROM calendar WHERE '".$today_date."' <= date ORDER BY date ASC LIMIT 5");
    while($rowCalendar=mysqli_fetch_assoc($qCalendar)){
        array_push($dataCalendar,$rowCalendar);
    }

    $dataN = array();
    $qN = mysqli_query($con, "SELECT * FROM notices ORDER BY date ASC LIMIT 5");
    while($rowN=mysqli_fetch_assoc($qN)){
        array_push($dataN,$rowN);
     }

    


    $q = mysqli_query($con, "SELECT * FROM users WHERE id='".$_REQUEST['id']."'");
    $row=mysqli_fetch_assoc($q);

    $qB = mysqli_query($con, "SELECT * FROM arrears WHERE student_id='".$row['id']."' AND term='".$_REQUEST['term']."' AND date='".$_REQUEST['year']."'");
    $rowB=mysqli_fetch_assoc($qB);

    $dataRecord = array();
    $qRecord = mysqli_query($con, "SELECT * FROM fees_record WHERE student_id='".$row['id']."' AND term='".$_REQUEST['term']."' AND year='".$_REQUEST['year']."' ORDER BY id DESC");
    while($rowRecord=mysqli_fetch_assoc($qRecord)){
        array_push($dataRecord,$rowRecord);
    }

    $bbf = $rowB['amount'];
    $new_bbf = $bbf - $bbf - $bbf;


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CEC - Admin</title>
        
        <link rel="stylesheet" href="../../vendors/iconfonts/font-awesome/css/all.min.css">
        <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
        <link rel="stylesheet" href="../../vendors/css/vendor.bundle.addons.css">
        <!-- endinject -->
        <script src="../../vendors/js/vendor.bundle.base.js"></script>
        <script src="../../vendors/js/vendor.bundle.addons.js"></script>
        <!-- endinject -->
        <!-- inject:js -->
        <script src="../../js/off-canvas.js"></script>
        <script src="../../js/hoverable-collapse.js"></script>
        <script src="../../js/misc.js"></script>
        <script src="../../js/settings.js"></script>
        <script src="../../js/todolist.js"></script>
        <!-- endinject -->
        <!-- Custom js for this page-->
        <script src="../../js/data-table.js"></script>
        <!-- plugin css for this page -->
        <!-- End plugin css for this page -->
        <!-- inject:css -->
        <link rel="stylesheet" href="../../css/style.css">
        <!-- endinject -->
        <link rel="shortcut icon" href="../../../../settings/<?php echo $rowS['favicon'] ?>" />
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        

<!--MAIN CONTENT-->


<div class="container bootdey">
    <div class="row">
		<div class="col-sm-10 col-sm-offset-1">
			
            <div class="page-header">
                <h3 class="page-title">
                Fees Statement for <?php echo $row['name']." ".$row['surname'] ?>
                </h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="all-news.php">View <?php echo $row['name']?></a></li>
                        <li class="breadcrumb-item active" aria-current="page">View Statement</li>
                    </ol>
                </nav>
            </div>

            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Term <?php echo $_REQUEST['term'].", ".$_REQUEST['year'] ?></h4>
                        <div class="row">
                            <?php if(isset($_REQUEST['error'])) { ?>
                                <div class="col-lg-12">
                                    <span class="alert alert-danger alert-block" style="display: block;"><?php echo $_REQUEST['error']; ?></span>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="row">
                            <?php if(isset($_REQUEST['success'])) { ?>
                                <div class="col-lg-12">
                                    <span class="alert alert-success alert-block" style="display: block;"><?php echo $_REQUEST['success']; ?></span>
                                </div>
                            <?php } ?>
                        </div>

                        <table class="table">
                            <tr>
                                <th><h3>Debit</h3></th>
                                <th><h3>Credit</h3></th>
                            </tr>
                            <tr>
                                <td><h5><?php echo "Balance B/F: $".$new_bbf; ?></h5></td>
                                <td><h5><?php foreach($dataRecord as $dR){
                                    echo $dR['date']." Paid Fees: ".$dR['amount']."<br><br>";
                                } ?><br></h5></td>
                            </tr>
                            <tr>
                                <td><h5><?php echo "Total Fees: $".$rowB['total']; ?></h5></td>
                                <td><h5><?php // echo "Arrears: $".$row['arrears']; ?></h5></td>
                            </tr>
                        </table>

                        <br><hr><br>

                        <div class="space-6"><button onclick="window.print()" class="btn btn-success">Print Statement</button>  <a href="view-student.php?id=<?php echo $row['id']; ?>" class="btn btn-success">Home</a></div><br>

    
                    </div>
                </div>
            </div>

		</div>
	</div>
</div>
        </body>

        <?php } else { 
        session_destroy();
        header("Location:../../index.php");
    } ?>
</html>