<?php

session_start();
include '../../../../database/connect.php' ;
$id=$_REQUEST['id'];
$q_update=mysqli_query($con, "UPDATE users set rank=8 where id='".$_REQUEST['id']."'");
if (isset($id)){
    header("Location:view-student.php?success=Locked Account Successfully&id=$id");    
}


?>