<?php 
include "../../../../database/connect.php";
session_start(); 
if(isset($_SESSION['user_data'])){
    if($_SESSION['user_data']['rank']!=4){
        if($_SESSION['user_data']['rank']!=1){
            session_destroy();
            header("Location:../../logout.php");
        }
        
    }

    $today_date = date("Y-m-d");

    if(!isset($_REQUEST['student_id'])){
        header("Location:all-students.php?error=Please Enter ID");
    }

    $f = mysqli_query($con, "SELECT * FROM users where id='".$_REQUEST['student_id']."'");
    $row=mysqli_fetch_assoc($f);

    $u = mysqli_query($con, "SELECT * FROM users where id='".$_SESSION['user_data']['id']."'");
    $row2=mysqli_fetch_assoc($u);

    $new=mysqli_real_escape_string($con,$_REQUEST['amount']);

    if ($new > 0) {
        $bbf = $new;
    } else {
        $bbf = $new * -1;
    }
    

    // $fees_record = mysqli_query($con, "INSERT INTO fees_record (student_id,amount,form,term, year) values ('".$_REQUEST['student_id']."','".$amount."','".$form."','".$term."','".$year."')");
    $q = mysqli_query($con, "UPDATE users SET bbf='".$bbf."' WHERE id='".$_REQUEST['student_id']."'");

    $id = $_REQUEST['student_id'];
    // header("Location:receipt.php?success=Edited Fees Successfully");
    if ($q) {
        header("Location:view-student.php?success=Added Balance B/F Successfully&id=$id");
    }
    else {
        header("Location:view-student.php?success=Failed to Add Balance B/F&id=$id");
    }

}
?>