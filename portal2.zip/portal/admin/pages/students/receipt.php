<?php
session_start();
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    if($_SESSION['user_data']['rank']!=4){
        if($_SESSION['user_data']['rank']!=1){
            session_destroy();
            header("Location:../../logout.php");
        }
        
    }

    $today_date = date("Y-m-d");

$qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1");
$rowS=mysqli_fetch_assoc($qS);

    $dataCalendar = array();
    $qCalendar = mysqli_query($con, "SELECT * FROM calendar WHERE '".$today_date."' <= date ORDER BY date ASC LIMIT 5");
    while($rowCalendar=mysqli_fetch_assoc($qCalendar)){
        array_push($dataCalendar,$rowCalendar);
    }

    $dataN = array();
    $qN = mysqli_query($con, "SELECT * FROM notices ORDER BY date ASC LIMIT 5");
    while($rowN=mysqli_fetch_assoc($qN)){
        array_push($dataN,$rowN);
     }

    




$update1 = mysqli_query($con, "SELECT * FROM fees_record WHERE id = (SELECT MAX(id) FROM fees_record)");
$row1 = mysqli_fetch_array($update1);

$update = mysqli_query($con, "SELECT * FROM users WHERE id='".$row1['student_id']."'");
$row = mysqli_fetch_array($update);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo $rowS['short_name'] ?> - Admin</title>
        
        <link rel="stylesheet" href="../../vendors/iconfonts/font-awesome/css/all.min.css">
        <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
        <link rel="stylesheet" href="../../vendors/css/vendor.bundle.addons.css">
        <!-- endinject -->
        <script src="../../vendors/js/vendor.bundle.base.js"></script>
        <script src="../../vendors/js/vendor.bundle.addons.js"></script>
        <!-- endinject -->
        <!-- inject:js -->
        <script src="../../js/off-canvas.js"></script>
        <script src="../../js/hoverable-collapse.js"></script>
        <script src="../../js/misc.js"></script>
        <script src="../../js/settings.js"></script>
        <script src="../../js/todolist.js"></script>
        <!-- endinject -->
        <!-- Custom js for this page-->
        <script src="../../js/data-table.js"></script>
        <!-- plugin css for this page -->
        <!-- End plugin css for this page -->
        <!-- inject:css -->
        <link rel="stylesheet" href="../../css/style.css">
        <!-- endinject -->
        <link rel="shortcut icon" href="../../../../settings/<?php echo $rowS['favicon'] ?>" />
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        

<!--MAIN CONTENT-->


<div class="container bootdey">
<div class="row">
		<div class="col-sm-10 col-sm-offset-1">
			<div class="widget-box">
				<div class="widget-header widget-header-large">
				    <br><br><br>
					<h4 class="widget-title grey lighter">
					<?php echo $rowS['name'] ?>
					</h4>
					

					<div class="widget-toolbar no-border invoice-info">
						<div class="row">
							<div class="col-sm-6">
								<span class="invoice-info-label">Receipt Number:</span>
								<span class="red">#<?php echo ($row1['id']) ?></span>
							</div>
							<div class="col-sm-6">
								<span class="invoice-info-label">Date:</span>
								<span class="blue"><?php echo ($row1['date']) ?></span>
							</div>
						</div>
					</div>

					<div class="widget-toolbar hidden-480">
						<!-- <a href="#">
							<i class="ace-icon fa fa-print"></i>
						</a> -->
					</div><br>
				</div>

				<div class="widget-body">
					<div class="widget-main padding-24">
						<div class="row">
							<div class="col-sm-6">
								<div class="row">
									<div class="col-xs-11 label label-lg label-info arrowed-in arrowed-right">
										<b><?php echo $rowS['name'] ?> Info</b>
									</div>
								</div>

								<div>
									<ul class="list-unstyled spaced">
										<li>
											<i class="ace-icon fa fa-caret-right blue"></i><?php echo $rowS['address'] ?>
										</li>

										<li>
											<i class="ace-icon fa fa-caret-right blue"></i>Zimbabwe
										</li>

										<li>
											<i class="ace-icon fa fa-caret-right blue"></i>
                                        Phone:
											<b class="red"><?php echo $rowS['phone'] ?></b>
										</li>

										<li class="divider"></li>

										<li>
											<i class="ace-icon fa fa-caret-right blue"></i>
											Email: <?php echo $rowS['email'] ?>
										</li>
									</ul>
								</div>
							</div><!-- /.col -->

							<div class="col-sm-6">
								<div class="row">
									<div class="col-xs-11 label label-lg label-success arrowed-in arrowed-right">
										<b>Student Info</b>
									</div>
								</div>

								<div>
									<ul class="list-unstyled  spaced">
										<li>
											<i class="ace-icon fa fa-caret-right green"></i><?php echo ($row['name']." ".$row['surname']); ?>
										</li>

										<li>
											<i class="ace-icon fa fa-caret-right green"></i>Form <?php echo ($row1['form']) ?>
										</li>

										<li>
											<i class="ace-icon fa fa-caret-right green"></i><?php echo ($row['class']) ?>
										</li>

										<li class="divider"></li>

									</ul>
								</div>
							</div><!-- /.col -->
						</div><!-- /.row -->

						<div class="space"></div>

						<div>
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th class="center">Form</th>
										<th>Term</th>
										<th class="hidden-xs">Issued By</th>
										<th>Amount</th>
									</tr>
								</thead>

								<tbody>
									<tr>
										<td class="center"><?php echo ($row1['form']) ?></td>

										<td class="center">
                                            <?php echo ($row1['term']) ?>
										</td>
										<td class="hidden-480"> <?php echo ($_SESSION['user_data']['title']." ".$_SESSION['user_data']['surname']); ?> </td>
										<td><?php echo "$".($row1['amount']) ?></td>
									</tr>

									
								</tbody>
							</table>
						</div>

						<div class="hr hr8 hr-double hr-dotted"></div>

						<div class="row">
							<div class="col-sm-5 pull-right">
								<h5 class="pull-right">
									Total amount :
									<span class="red"><?php echo "$".($row1['amount']) ?></span>
								</h5>
							</div>

						</div>



						<!-- <div class="space-6"><button onclick="window.print()" class="btn btn-success">Print Receipt</button>  <a href="view-student.php?id=<?php echo $row1['student_id']; ?>" class="btn btn-success">Home</a></div><br> -->
						<div class="well">
							Thank you for choosing <?php echo $rowS['name'] ?>. 
						</div>
					</div>
				</div>

				<br><br><hr><br><br>


				<div class="widget-header widget-header-large">
				    
					<h4 class="widget-title grey lighter">
					<?php echo $rowS['name'] ?>
					</h4><br>
					<p>Admin Copy</p>
					

					<div class="widget-toolbar no-border invoice-info">
						<div class="row">
							<div class="col-sm-6">
								<span class="invoice-info-label">Receipt Number:</span>
								<span class="red">#<?php echo ($row1['id']) ?></span>
							</div>
							<div class="col-sm-6">
								<span class="invoice-info-label">Date:</span>
								<span class="blue"><?php echo ($row1['date']) ?></span>
							</div>
						</div>
					</div>

					<div class="widget-toolbar hidden-480">
						<!-- <a href="#">
							<i class="ace-icon fa fa-print"></i>
						</a> -->
					</div><br>
				</div>

				<div class="widget-body">
					<div class="widget-main padding-24">
						<div class="row">
							<div class="col-sm-6">
								<div class="row">
									<div class="col-xs-11 label label-lg label-info arrowed-in arrowed-right">
										<b>College Info</b>
									</div>
								</div>

								<div>
									<ul class="list-unstyled spaced">
										<li>
											<i class="ace-icon fa fa-caret-right blue"></i><?php echo $rowS['address'] ?>
										</li>

										<li>
											<i class="ace-icon fa fa-caret-right blue"></i>Zimbabwe
										</li>

										<li>
											<i class="ace-icon fa fa-caret-right blue"></i>
                                        Phone:
											<b class="red"><?php echo $rowS['phone'] ?></b>
										</li>

										<li class="divider"></li>

										<li>
											<i class="ace-icon fa fa-caret-right blue"></i>
											Email: <?php echo $rowS['email'] ?>
										</li>
									</ul>
								</div>
							</div><!-- /.col -->

							<div class="col-sm-6">
								<div class="row">
									<div class="col-xs-11 label label-lg label-success arrowed-in arrowed-right">
										<b>Student Info</b>
									</div>
								</div>

								<div>
									<ul class="list-unstyled  spaced">
										<li>
											<i class="ace-icon fa fa-caret-right green"></i><?php echo ($row['name']." ".$row['surname']); ?>
										</li>

										<li>
											<i class="ace-icon fa fa-caret-right green"></i>Form <?php echo ($row1['form']) ?>
										</li>

										<li>
											<i class="ace-icon fa fa-caret-right green"></i><?php echo ($row['class']) ?>
										</li>

										<li class="divider"></li>

									</ul>
								</div>
							</div><!-- /.col -->
						</div><!-- /.row -->

						<div class="space"></div>

						<div>
							<table class="table table-striped table-bordered">
								<thead>
									<tr>
										<th class="center">Form</th>
										<th>Term</th>
										<th class="hidden-xs">Issued By</th>
										<th>Amount</th>
									</tr>
								</thead>

								<tbody>
									<tr>
										<td class="center"><?php echo ($row1['form']) ?></td>

										<td class="center">
                                            <?php echo ($row1['term']) ?>
										</td>
										<td class="hidden-480"> <?php echo ($_SESSION['user_data']['title']." ".$_SESSION['user_data']['surname']); ?> </td>
										<td><?php echo "$".($row1['amount']) ?></td>
									</tr>

									
								</tbody>
							</table>
						</div>

						<div class="hr hr8 hr-double hr-dotted"></div>

						<div class="row">
							<div class="col-sm-5 pull-right">
								<h5 class="pull-right">
									Total amount :
									<span class="red"><?php echo "$".($row1['amount']) ?></span>
								</h5>
							</div>

						</div>

						<br><hr><br>

						<div class="space-6"><button onclick="window.print()" class="btn btn-success">Print Receipt</button>  <a href="view-student.php?id=<?php echo $row1['student_id']; ?>" class="btn btn-success">Home</a></div><br>
						<!-- <div class="well">
							Thank you for choosing <?php echo $rowS['name'] ?>. 
						</div> -->
					</div>
				</div>


			</div>
		</div>
	</div>
</div>
        </body>

        <?php } else { 
        session_destroy();
        header("Location:../../index.php");
    } ?>
</html>