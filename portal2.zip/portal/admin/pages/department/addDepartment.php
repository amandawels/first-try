<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$type=mysqli_real_escape_string($con,$_REQUEST['type']);
$name=mysqli_real_escape_string($con,$_REQUEST['name']);
$content=mysqli_real_escape_string($con,$_REQUEST['content']);

$pic = time() . '_' . $_FILES['pic']['name'];
$destination = "../../../images/department/" . $pic;
$result = move_uploaded_file($_FILES['pic']['tmp_name'], $destination);


$q = mysqli_query($con, "INSERT into department (type, name, content, pic) values ('".$type."','".$name."','".$content."','".$pic."')");
if ($q) {
    header("Location:all-departments.php?success=Added Successfully");
}
else {
    header("Location:all-departments.php?error=Failed to add Department/Club");
}
?>