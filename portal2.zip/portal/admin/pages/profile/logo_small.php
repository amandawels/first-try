<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}

$logo_small = time() . '_' . $_FILES['logo_small']['name'];
$destination = "../../../../settings/" . $logo_small;
$result = move_uploaded_file($_FILES['logo_small']['tmp_name'], $destination);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into settings (slide_pic_1) values ('".$slide_pic_1."') WHERE id=1");
    $q1 = mysqli_query($con, "UPDATE settings SET logo_small='".$logo_small."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated Small Logo Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to Update Small Logo");
    }  
}

?>