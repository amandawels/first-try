<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
// $pich = $_FILES['objectives_pic_1']['name'] . 'fuck';
$objectives=mysqli_real_escape_string($con,$_REQUEST['objectives']);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into settings (slide_pic_1) values ('".$slide_pic_1."') WHERE id=1");

    $pich1 = $_FILES['objectives_pic_1']['name'] . 'fuck_1';

    $objectives_pic_1 = time() . '_' . $_FILES['objectives_pic_1']['name'];
    $destination = "../../../../settings/" . $objectives_pic_1;
    $result = move_uploaded_file($_FILES['objectives_pic_1']['tmp_name'], $destination);

    $pich2 = $_FILES['objectives_pic_2']['name'] . 'fuck_2';

    $objectives_pic_2 = time() . '_' . $_FILES['objectives_pic_2']['name'];
    $destination = "../../../../settings/" . $objectives_pic_2;
    $result = move_uploaded_file($_FILES['objectives_pic_2']['tmp_name'], $destination);

    $pich3 = $_FILES['objectives_pic_3']['name'] . 'fuck_3';

    $objectives_pic_3 = time() . '_' . $_FILES['objectives_pic_3']['name'];
    $destination = "../../../../settings/" . $objectives_pic_3;
    $result = move_uploaded_file($_FILES['objectives_pic_3']['tmp_name'], $destination);

    if($pich1 == "fuck_1" && $pich2 =="fuck_2" && $pich3 == "fuck_3"){
        // echo "fuck haipo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET objectives='".$_REQUEST['objectives']."' WHERE id=1");
    } elseif ($pich1 == "fuck_1" && $pich2 =="fuck_2"){
        $q1 = mysqli_query($con, "UPDATE settings SET objectives_pic_3='".$objectives_pic_3."', objectives='".$_REQUEST['objectives']."' WHERE id=1");
    } elseif ($pich1 == "fuck_1" && $pich3 =="fuck_3"){
        $q1 = mysqli_query($con, "UPDATE settings SET objectives_pic_2='".$objectives_pic_2."', objectives='".$_REQUEST['objectives']."' WHERE id=1");
    } elseif ($pich1 == "fuck_1"){
        $q1 = mysqli_query($con, "UPDATE settings SET objectives_pic_2='".$objectives_pic_2."', objectives_pic_3='".$objectives_pic_3."', objectives='".$_REQUEST['objectives']."' WHERE id=1");
    } elseif ($pich2 =="fuck_2" && $pich3 == "fuck_3"){
        $q1 = mysqli_query($con, "UPDATE settings SET objectives_pic_1='".$objectives_pic_1."', objectives='".$_REQUEST['objectives']."' WHERE id=1");
    } elseif ($pich2 =="fuck_2"){
        $q1 = mysqli_query($con, "UPDATE settings SET objectives_pic_1='".$objectives_pic_1."', objectives_pic_3='".$objectives_pic_3."', objectives='".$_REQUEST['objectives']."' WHERE id=1");
    } elseif ($pich3 =="fuck_3"){
        $q1 = mysqli_query($con, "UPDATE settings SET objectives_pic_1='".$objectives_pic_1."', objectives_pic_2='".$objectives_pic_2."', objectives='".$_REQUEST['objectives']."' WHERE id=1");
    } else {
        
        // echo "fuck iripo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET objectives_pic_1='".$objectives_pic_1."',objectives_pic_2='".$objectives_pic_2."', objectives_pic_3='".$objectives_pic_3."', objectives='".$_REQUEST['objectives']."' WHERE id=1");
        
    }
    // $q1 = mysqli_query($con, "UPDATE settings SET objectives_pic_1='".$objectives_pic_1."', objectives_pic_1_head='".$_REQUEST['objectives_pic_1_head']."',objectives_pic_1_text='".$_REQUEST['objectives_pic_1_text']."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated School objectives Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to Update School objectives");
    }  
}

?>