<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
// $pich = $_FILES['mission_pic']['name'] . 'fuck';
$mission=mysqli_real_escape_string($con,$_REQUEST['mission']);
$message=mysqli_real_escape_string($con,$_REQUEST['message']);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into settings (slide_pic_1) values ('".$slide_pic_1."') WHERE id=1");

    $pich = $_FILES['mission_pic']['name'] . 'fuck';

    $mission_pic = time() . '_' . $_FILES['mission_pic']['name'];
    $destination = "../../../../settings/" . $mission_pic;
    $result = move_uploaded_file($_FILES['mission_pic']['tmp_name'], $destination);

    if($pich == "fuck"){
        // echo "fuck haipo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET message='".$_REQUEST['message']."', mission='".$_REQUEST['mission']."' WHERE id=1");
    } else {
        
        // echo "fuck iripo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET mission_pic='".$mission_pic."', message='".$_REQUEST['message']."', mission='".$_REQUEST['mission']."' WHERE id=1");
        
    }
    // $q1 = mysqli_query($con, "UPDATE settings SET mission_pic='".$mission_pic."', mission_pic_head='".$_REQUEST['mission_pic_head']."',mission_pic_text='".$_REQUEST['mission_pic_text']."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated School Mission and Director Message Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to Update School Mission and Director Message");
    }  
}

?>