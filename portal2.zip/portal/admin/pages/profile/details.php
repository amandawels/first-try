<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$name=mysqli_real_escape_string($con,$_REQUEST['name']);
$short_name=mysqli_real_escape_string($con,$_REQUEST['short_name']);
$motto=mysqli_real_escape_string($con,$_REQUEST['motto']);
$mission=mysqli_real_escape_string($con,$_REQUEST['mission']);
// $vision=mysqli_real_escape_string($con,$_REQUEST['vision']);
$address=mysqli_real_escape_string($con,$_REQUEST['address']);

// $pic = time() . '_' . $_FILES['pic']['name'];
// $destination = "../../../images/gallery/" . $pic;
// $result = move_uploaded_file($_FILES['pic']['tmp_name'], $destination);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into users (pic) values ('".$pic."') WHERE id='".$_REQUEST['id']."'");
    $q1 = mysqli_query($con, "UPDATE settings SET name='".$_REQUEST['name']."',short_name='".$_REQUEST['short_name']."',motto='".$_REQUEST['motto']."',mission='".$_REQUEST['mission']."', address='".$_REQUEST['address']."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated Details Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to update School Details");
    }  
}

?>