<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}

$logo_main = time() . '_' . $_FILES['logo_main']['name'];
$destination = "../../../../settings/" . $logo_main;
$result = move_uploaded_file($_FILES['logo_main']['tmp_name'], $destination);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into settings (slide_pic_1) values ('".$slide_pic_1."') WHERE id=1");
    $q1 = mysqli_query($con, "UPDATE settings SET logo_main='".$logo_main."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated Logo Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to Update Logo");
    }  
}

?>