<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}
$slide_pic_2_head=mysqli_real_escape_string($con,$_REQUEST['slide_pic_2_head']);
$slide_pic_2_text=mysqli_real_escape_string($con,$_REQUEST['slide_pic_2_text']);

$pich = $_FILES['slide_pic_2']['name'] . 'fuck';

$slide_pic_2 = time() . '_' . $_FILES['slide_pic_2']['name'];
$destination = "../../../../settings/" . $slide_pic_2;
$result = move_uploaded_file($_FILES['slide_pic_2']['tmp_name'], $destination);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into settings (slide_pic_2) values ('".$slide_pic_2."') WHERE id=1");
    // $q1 = mysqli_query($con, "UPDATE settings SET slide_pic_2='".$slide_pic_2."', slide_pic_2_head='".$_REQUEST['slide_pic_2_head']."',slide_pic_2_text='".$_REQUEST['slide_pic_2_text']."' WHERE id=1");

    if($pich == "fuck"){
        // echo "fuck haipo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET slide_pic_2_head='".$_REQUEST['slide_pic_2_head']."',slide_pic_2_text='".$_REQUEST['slide_pic_2_text']."' WHERE id=1");
    } else {
        
        // echo "fuck iripo";
        // echo $pich;
        $q1 = mysqli_query($con, "UPDATE settings SET slide_pic_2='".$slide_pic_2."', slide_pic_2_head='".$_REQUEST['slide_pic_2_head']."',slide_pic_2_text='".$_REQUEST['slide_pic_2_text']."' WHERE id=1");
        
    }
    if ($q1) {
        header("Location:profile.php?success=Updated Slider Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to Update Slider");
    }  
}

?>