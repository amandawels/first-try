<?php
include '../../../../database/connect.php';
if(isset($_SESSION['user_data'])){
    header("Location:../../logout.php");
}

$favicon = time() . '_' . $_FILES['favicon']['name'];
$destination = "../../../../settings/" . $favicon;
$result = move_uploaded_file($_FILES['favicon']['tmp_name'], $destination);

if(count($_POST)>0) {
    // $q = mysqli_query($con, "INSERT into settings (slide_pic_1) values ('".$slide_pic_1."') WHERE id=1");
    $q1 = mysqli_query($con, "UPDATE settings SET favicon='".$favicon."' WHERE id=1");
    if ($q1) {
        header("Location:profile.php?success=Updated Favicon Image Successfully");
    }
    else {
        header("Location:profile.php?error=Failed to Update Favicon Image");
    }  
}

?>