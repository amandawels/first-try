<?php

include 'header.php' ;

$term = $_REQUEST['term'];
$year = $_REQUEST['year'];
$id=$_REQUEST['id'];
$q_update=mysqli_query($con, "UPDATE publish set published=1 where id='".$_REQUEST['id']."' and school='".$school."'");
$published67=mysqli_query($con, "UPDATE end_marks set publish=1 where year='".$year."' and term='".$term."' and school='".$school."'");

    if (isset($id)){
        header("Location:publish.php?success=Published Results Successfully."); 
           
    }


?>