<?php
include 'header.php' ;;


if(count($_POST)>0) {
    mysqli_query($con, "UPDATE users SET term='".$_REQUEST['term']."' WHERE school='".$school."'");
    mysqli_query($con, "UPDATE term SET term='".$_REQUEST['term']."' WHERE school='".$school."' ");
    header("Location:home.php?success=Updated Term Successfully");
}