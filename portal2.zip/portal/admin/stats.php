<?php include 'header.php' ;

    $term = $_REQUEST['term'];
    $year = $_REQUEST['year'];
    $id = $_REQUEST['id'];
  

?>

<!DOCTYPE html>
<html lang="en">


<?php include "nav.php" ?>

      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
            <div class="page-header">
                <h3 class="page-title">
                Generate Statistics
                </h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="publish.php">Results</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Generate Statistics</li>
                    </ol>
                </nav>
            </div>

            <div class="col-12 grid-margin stretch-card">
                                    <div class="card">
                                        <div class="card-body">
                                        <h4 class="card-title">Generate Statistics</h4>
                                        <span style="color: red;"><small>You are about to generate statistics for Term <?php echo $term.", ".$year ?>. This function can only be performed once</small></span><br><br>
                                            <form action="statistics.php" method="post">
                                                <input type="hidden" name="id" value="<?php echo $id ?>">
                                                <input type="hidden" name="term" value="<?php echo $term ?>">
                                                <input type="hidden" name="year" value="<?php echo $year ?>">
                                                <button type="submit" class="btn btn-success">Generate Statistics</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>







            <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php $year=date("Y"); echo $year; ?>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="far fa-heart text-danger"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/data-table.js"></script>
  <!-- End custom js for this page-->
</body>
<?php } else { 
        session_destroy();
        header("Location:HOME");
    } ?>

</html>
