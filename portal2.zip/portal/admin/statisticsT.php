<?php

include 'header.php' ;

$term = $_REQUEST['term'];
$year = $_REQUEST['year'];
$test_number = $_REQUEST['test_number'];

// Subject Statistics
  
$dataGrade = array();
$qGrade = mysqli_query($con, "SELECT * FROM grade WHERE school='".$school."' ORDER BY grade ASC");
while($rowGrade=mysqli_fetch_assoc($qGrade)){
    array_push($dataGrade,$rowGrade);
}
$dataClasses = array();
$qClasses = mysqli_query($con, "SELECT * FROM classes WHERE school='".$school."' ORDER BY class ASC");
while($rowClasses=mysqli_fetch_assoc($qClasses)){
    array_push($dataClasses,$rowClasses);
}
foreach ($dataGrade as $dGrade){
    foreach ($dataClasses as $dClasses){
        $dataSubjects = array();
        $qSubjects = mysqli_query($con, "SELECT * FROM subs WHERE form='".$dGrade['grade']."' AND class='".$dClasses['class']."' AND school='".$school."' ORDER BY subject ASC");
        while($rowSubjects=mysqli_fetch_assoc($qSubjects)){
            array_push($dataSubjects,$rowSubjects);
        }
        foreach($dataSubjects as $dSubject){
            $end = mysqli_query($con, "SELECT COUNT(id) FROM end_test WHERE test_number='".$test_number."' AND year='".$year."' AND term='".$term."' AND subject='".$dSubject['subject']."' AND form='".$dGrade['grade']."' AND class='".$dClasses['class']."' AND school='".$school."'");
            $rowEnd=mysqli_fetch_array($end);
            $totalEnd = $rowEnd[0];
    
            $passed = mysqli_query($con, "SELECT COUNT(id) FROM end_test WHERE test_number='".$test_number."' AND year='".$year."' AND term='".$term."' AND subject='".$dSubject['subject']."' AND form='".$dGrade['grade']."' AND mark>49 AND class='".$dClasses['class']."' AND school='".$school."'");
            $rowPassed=mysqli_fetch_array($passed);
            $totalPassed = $rowPassed[0];
    
            $year2 = $year-1;
            $number=mysqli_query($con, "SELECT * FROM percent_test WHERE test_number='".$test_number."' AND form='".$dGrade['grade']."' AND subject='".$dSubject['subject']."' AND term='".$term."' AND year='".$year2."' AND class='".$dClasses['class']."' AND school='".$school."'");
            $row=mysqli_fetch_assoc($number);
    
            if (isset($row['number'])){
                $number = $row['number']+1;
            } else{
                $number=1;
            }
            $percent_previous = $row['percent_previous'];
            $class = $dClasses['class'];
            
            $q = mysqli_query($con, "INSERT INTO percent_test (number, test_number, form, term, class, year, subject, total_students, passed, percent_previous) VALUES ('".$number."','".$test_number."','".$dGrade['grade']."','".$term."','".$class."','".$year."','".$dSubject['subject']."','".$totalEnd."','".$totalPassed."','".$row['percent_passed']."') WHERE school='".$school."'");
            
        }
    }
    
}
$q_update=mysqli_query($con, "UPDATE publishtest SET generate=1 WHERE id='".$_REQUEST['id']."' AND school='".$school."'");

if ($q){
    header("Location:publishT.php?success=Successfully Generated Results Statistics. Click the Statistics link to view the Statistics.");     
} else {
    header("Location:publishT.php?error=Failed to Generate Statisctics");
}





?>