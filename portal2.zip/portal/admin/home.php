<?php include "header.php" ?>
<?php

    $term = mysqli_query($con, "SELECT * FROM term WHERE id='1' AND school='".$school."'");
    $t=mysqli_fetch_assoc($term);

    $data2 = array();
    $q2 = mysqli_query($con, "SELECT * FROM classes WHERE school='".$school."' ORDER BY class ASC");
    while($row2=mysqli_fetch_assoc($q2)){
        array_push($data2,$row2);
    }

    $data = array();
    $q = mysqli_query($con, "SELECT * FROM contact WHERE school='".$school."' ORDER BY id DESC LIMIT 5");
    while($row=mysqli_fetch_assoc($q)){
        array_push($data,$row);
    }
    $eCount = mysqli_query($con, "SELECT COUNT(id) FROM contact WHERE school='".$school."'");
    $rowCount=mysqli_fetch_array($eCount);
    $total = $rowCount[0];



    $data2 = array();
    $q2 = mysqli_query($con, "SELECT * FROM sb WHERE school='".$school."' ORDER BY id DESC LIMIT 4");
    while($row2=mysqli_fetch_assoc($q2)){
        array_push($data2,$row2);
    }
    $eCount2 = mysqli_query($con, "SELECT COUNT(id) FROM sb WHERE school='".$school."'");
    $rowCount2=mysqli_fetch_array($eCount2);
    $total2 = $rowCount2[0];

    $eCountStudent = mysqli_query($con, "SELECT COUNT(id) FROM users WHERE rank>6 AND form<7 AND school='".$school."'");
    $rowCountStudent=mysqli_fetch_array($eCountStudent);
    $totalStudent = $rowCountStudent[0];

    $eCountStaff = mysqli_query($con, "SELECT COUNT(id) FROM users WHERE RANK<7 AND school='".$school."'");
    $rowCountStaff=mysqli_fetch_array($eCountStaff);
    $totalStaff = $rowCountStaff[0];

    $eCountDownloads = mysqli_query($con, "SELECT COUNT(id) FROM downloads WHERE school='".$school."'");
    $rowCountDownloads=mysqli_fetch_array($eCountDownloads);
    $totalDownloads = $rowCountDownloads[0];

    $today_date = date("Y-m-d");

    

    
?>

<!DOCTYPE html>
<html lang="en">


<?php include "nav.php" ?>

      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
            <h3 class="page-title">
              Dashboard
            </h3>
          </div>
          <div class="row grid-margin">
            <div class="col-lg-3 col-md-2 col-sm-1 col-xs-1"></div>
            <div class="col-lg-6 col-md-8 col-sm-10 col-xs-10">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="d-flex flex-column flex-md-row align-items-center justify-content-between">
                      <div class="statistics-item">
                        <p>
                          <i class="icon-sm fa fa-user mr-2"></i>
                          Students
                        </p>
                        <h2><?php echo $totalStudent ?></h2>
                        <!-- <label class="badge badge-outline-success badge-pill">2.7% increase</label> -->
                      </div>
                      <div class="statistics-item">
                        <p>
                          <i class="icon-sm fas fa-user mr-2"></i>
                          Staff
                        </p>
                        <h2><?php echo $totalStaff ?></h2>
                        <!-- <label class="badge badge-outline-danger badge-pill">2% decrease</label> -->
                      </div>
                      <div class="statistics-item">
                        <p>
                          <i class="icon-sm fas fa-cloud-download-alt mr-2"></i>
                          Downloads
                        </p>
                        <h2><?php echo $totalDownloads ?></h2>
                        <!-- <label class="badge badge-outline-success badge-pill">12% increase</label> -->
                      </div>
                      
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-2 col-sm-1 col-xs-1"></div>
          </div>
          <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                <div class="row">
                            <?php if(isset($_REQUEST['success'])) { ?>
                                <div class="col-lg-12">
                                    <span class="alert alert-success alert-block" style="display: block;"><?php echo $_REQUEST['success']; ?></span>
                                </div>
                            <?php } ?>
                        </div>  
                        <div class="row">
                            <?php if(isset($_REQUEST['error'])) { ?>
                                <div class="col-lg-12">
                                    <span class="alert alert-danger alert-block" style="display: block;"><?php echo $_REQUEST['error']; ?></span>
                                </div>
                            <?php } ?>
                        </div>
                  <h4 class="card-title">Update Term</h4>

                  <p class="card-description">
                    This is the current term
                  </p>
                  <form action="term.php" method="POST">
                    <div class="form-group">
                        <div class="input-group">
                            <input type="number" name="term" class="form-control" placeholder="Term" aria-label="term" value="<?php echo $t['term'] ?>">
                            <div class="input-group-append">
                                <button class="btn btn-sm btn-primary" type="submit">Update Term</button>
                            </div>
                        </div>
                    </div>
                  </form>
                  
                </div>
              </div>
            </div>
          
          <div class="row">
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">
                    <i class="fas fa-envelope"></i>
                    Inbox(<?php echo $total ?>)
                  </h4>
                  <div class="table-responsive">
                    <table class="table">
                      <tbody>
                        <?php
                            foreach($data as $d) {
                        ?>
                        <tr>
                            <td class="py-1">
                                <img src="<?php echo "../../images/users/comment.jpg" ?>" alt="profile" class="img-sm rounded-circle"/>
                            </td>
                            <td class="font-weight-bold">
                            <?php echo $d['name']; ?>
                            </td>
                            <td>
                                <a href="pages/emails/email-detail.php?id=<?php echo $d['id']; ?>"><span style="color: black;"><?php echo html_entity_decode(substr($d['comment'], 0, 50).'...') ?></span></a>
                            </td>
                            <td>
                                <label class="badge badge-success badge-pill"><a href="pages/emails/email-detail.php?id=<?php echo $d['id']; ?>"><span style="color: white;">New</span></a></label>
                            </td>
                        </tr>
                        <?php } ?>
                        
                      </tbody>
                    </table><br>
                    <a href="pages/emails/emails.php">see more</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-8 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">
                    <i class="fas fa-table"></i>
                    Suggestion Box (<?php echo $total2; ?>)
                  </h4>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Date</th>
                          <th>Content</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                            foreach($data2 as $d2) {
                          ?>
                      <tr>
                          
                          <td class="font-weight-bold">
                            <span style="color: black;"><?php echo $d2['name']." ".$d2['surname']; ?></span>
                          </td>
                          <td class="text-muted">
                            <?php echo $d2['date']; ?>
                          </td>
                          <td>
                            <a href="pages/sb/sb-detail.php?id=<?php echo $d2['id']; ?>"><span style="color: black;"><?php echo html_entity_decode(substr($d2['content'], 0, 50).'...') ?></span></a>
                          </td>
                          <td>
                              <label class="badge badge-success badge-pill"><a href="pages/sb/sb-detail.php?id=<?php echo $d2['id']; ?>"><span style="color: white;">1</span></a></label>
                          </td>

                      </tr>
                      <?php } ?>
                        
                      </tbody>
                    </table><br>
                    <a href="<?php echo (BASE_URL . "/pages/sb/sb.php"); ?>">view more</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">
                    <i class="fas fa-calendar-alt"></i>
                    Calendar
                  </h4>
                  <div id="inline-datepicker-example" class="datepicker"></div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <div class="d-md-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center mb-3 mb-md-0">
                      <button class="btn btn-social-icon btn-facebook btn-rounded">
                        <i class="fab fa-facebook-f"></i>
                      </button>
                      <div class="ml-4">
                        <h5 class="mb-0">Facebook</h5>
                        <p class="mb-0">813 friends</p>
                      </div>
                    </div>
                    <div class="d-flex align-items-center mb-3 mb-md-0">
                      <button class="btn btn-social-icon btn-twitter btn-rounded">
                        <i class="fab fa-twitter"></i>
                      </button>
                      <div class="ml-4">
                        <h5 class="mb-0">Instagram</h5>
                        <p class="mb-0">9000 followers</p>
                      </div>
                    </div>
                    <div class="d-flex align-items-center mb-3 mb-md-0">
                      <button class="btn btn-social-icon btn-google btn-rounded">
                        <i class="fab fa-google-plus-g"></i>
                      </button>
                      <div class="ml-4">
                        <h5 class="mb-0">Twitter</h5>
                        <p class="mb-0">780 friends</p>
                      </div>
                    </div>
                    <div class="d-flex align-items-center">
                      <button class="btn btn-social-icon btn-linkedin btn-rounded">
                        <i class="fab fa-linkedin-in"></i>
                      </button>
                      <div class="ml-4">
                        <h5 class="mb-0">Linkedin</h5>
                        <p class="mb-0">1090 connections</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php $year=date("Y"); echo $year; ?>. All rights reserved.</span>

          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>
<?php } else { 
        session_destroy();
        header("Location:index.php");
    } ?>


</html>
