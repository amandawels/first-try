<?php

session_start();
if(isset($_SESSION['user_data'])){
    if($_SESSION['user_data']['rank']!=4){
        if($_SESSION['user_data']['rank']!=1){
            session_destroy();
            header("Location:logout.php");
        }
        
    }

    include '../../database/connect.php' ;

    $school = $_SESSION['user_data']['school'];

    $q = mysqli_query($con, "SELECT * FROM users WHERE id='".$_SESSION['user_data']['id']."' AND school='".$school."'");
    $row=mysqli_fetch_assoc($q);


    $qS = mysqli_query($con, "SELECT * FROM settings WHERE id=1 AND school='".$school."'");
    $rowS=mysqli_fetch_assoc($qS);

    $today_date = date("Y-m-d");

    $dataCalendar = array();
    $qCalendar = mysqli_query($con, "SELECT * FROM calendar WHERE '".$today_date."' <= date AND school='".$school."' ORDER BY date ASC LIMIT 5");
    while($rowCalendar=mysqli_fetch_assoc($qCalendar)){
        array_push($dataCalendar,$rowCalendar);
    }

    $dataN = array();
    $qN = mysqli_query($con, "SELECT * FROM notices WHERE school='".$school."' ORDER BY date ASC LIMIT 5");
    while($rowN=mysqli_fetch_assoc($qN)){
        array_push($dataN,$rowN);
     }
