<?php

include 'header.php' ;

$term = $_REQUEST['term'];
$year = $_REQUEST['year'];
$id=$_REQUEST['id'];

$q_update=mysqli_query($con, "UPDATE publish SET published=0 WHERE id='".$_REQUEST['id']."' AND school='".$school."'");
$published67=mysqli_query($con, "UPDATE end_marks SET publish=0 WHERE year='".$year."' AND term='".$term."' AND school='".$school."'");
if (isset($id)){
    header("Location:publish.php?error=Unpublished Results Successfully");    
}


?>